﻿namespace TicTacToeLib
{
    public class Game
    {
        private readonly char[,] board;
        private char currentPlayer;

        public Game()
        {
            board = new char[3, 3];
            currentPlayer = 'X';
        }

        public char CurrentPlayer => currentPlayer;

        public bool MakeMove(int row, int col)
        {
            if (row < 0 || row >= 3 || col < 0 || col >= 3 || board[row, col] != '\0')
            {
                return false; // Movimento Inválido
            }

            board[row, col] = currentPlayer;
            return true;
        }

        public bool CheckWinner(out char winner)
        {
            // Verifica linhas, colunas e diagonais
            for (int i = 0; i < 3; i++)
            {
                if (board[i, 0] == currentPlayer && board[i, 1] == currentPlayer && board[i, 2] == currentPlayer ||
                    board[0, i] == currentPlayer && board[1, i] == currentPlayer && board[2, i] == currentPlayer)
                {
                    winner = currentPlayer;
                    return true;
                }
            }

            // Verifica diagonais
            if (board[0, 0] == currentPlayer && board[1, 1] == currentPlayer && board[2, 2] == currentPlayer ||
                board[0, 2] == currentPlayer && board[1, 1] == currentPlayer && board[2, 0] == currentPlayer)
            {
                winner = currentPlayer;
                return true;
            }

            // Ninguém ganha
            winner = '\0';
            return false;
        }

        public bool IsBoardFull()
        {
            foreach (var cell in board)
            {
                if (cell == '\0') return false;
            }
            return true;
        }

        public void SwitchPlayer()
        {
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        public char[,] GetBoard()
        {
            return board.Clone() as char[,];
        }
    }

}
