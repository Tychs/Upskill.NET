using TicTacToeLib;
namespace TicTacToeForms
{
    public partial class Form1 : Form
    {
        private char[,] board; // Estado do tabuleiro
        private char currentPlayer; // Jogador atual ('X' ou 'O')
        private Image xImage;
        private Image oImage;
        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            // Inicializa o estado do tabuleiro
            board = new char[3, 3];
            currentPlayer = 'X';

            // Carrega as imagens dos jogadores
            xImage = Image.FromFile("X.png");
            oImage = Image.FromFile("O.png");

            // Associa eventos aos bot�es do tabuleiro
            foreach (var control in tableLayoutPanel1.Controls.OfType<Button>())
            {
                control.Click += Button_Click;
            }

            // Configura os eventos dos bot�es de controle
            btNew.Click += btNew_Click;
            btRandom.Click += btRandom_Click;
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;

            // Obter as coordenadas do bot�o clicado
            int row = tableLayoutPanel1.GetRow(clickedButton);
            int col = tableLayoutPanel1.GetColumn(clickedButton);

            // Verificar se a c�lula est� vazia
            if (board[row, col] != '\0') return;

            // Atualiza o estado do tabuleiro
            board[row, col] = currentPlayer;

            // Atualiza o bot�o com a imagem do jogador atual
            clickedButton.Image = currentPlayer == 'X' ? xImage : oImage;

            // Verifica se o jogo foi vencido
            if (CheckWinner(out char winner))
            {
                MessageBox.Show($"Jogador {winner} venceu!");
                ResetGame();
                return;
            }

            // Verifica se o tabuleiro est� cheio (empate)
            if (IsBoardFull())
            {
                MessageBox.Show("Empate!");
                ResetGame();
                return;
            }

            // Alterna para o pr�ximo jogador
            currentPlayer = currentPlayer == 'X' ? 'O' : 'X';
        }

        private void btNew_Click(object sender, EventArgs e)
        {
            ResetGame();
        }

        private void btRandom_Click(object sender, EventArgs e)
        {
            // Encontra c�lulas vazias no tabuleiro
            var emptyCells = Enumerable.Range(0, 3)
                .SelectMany(row => Enumerable.Range(0, 3)
                    .Where(col => board[row, col] == '\0')
                    .Select(col => new { row, col }))
                .ToList();

            // Se n�o h� c�lulas vazias, faz nada
            if (!emptyCells.Any()) return;

            // Escolhe uma c�lula vazia aleatoriamente
            var random = new Random();
            var cell = emptyCells[random.Next(emptyCells.Count)];

            // Atualiza o estado do tabuleiro e o bot�o correspondente
            board[cell.row, cell.col] = currentPlayer;
            var button = tableLayoutPanel1.GetControlFromPosition(cell.col, cell.row) as Button;
            if (button != null)
            {
                button.Image = currentPlayer == 'X' ? xImage : oImage;
            }

            // Verifica se o jogo foi vencido
            if (CheckWinner(out char winner))
            {
                MessageBox.Show($"Jogador {winner} venceu!");
                ResetGame();
                return;
            }

            // Alterna para o pr�ximo jogador
            currentPlayer = currentPlayer == 'X' ? 'O' : 'X';
        }

        private void ResetGame()
        {
            // Limpa o tabuleiro
            board = new char[3, 3];

            // Limpa os bot�es
            foreach (var control in tableLayoutPanel1.Controls.OfType<Button>())
            {
                control.Image = null;
            }

            // Reinicia para o jogador 'X'
            currentPlayer = 'X';
        }

        private bool CheckWinner(out char winner)
        {
            // Verifica linhas e colunas
            for (int i = 0; i < 3; i++)
            {
                if (board[i, 0] != '\0' && board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2] ||
                    board[0, i] != '\0' && board[0, i] == board[1, i] && board[1, i] == board[2, i])
                {
                    winner = currentPlayer;
                    return true;
                }
            }

            // Verifica diagonais
            if (board[0, 0] != '\0' && board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2] ||
                board[0, 2] != '\0' && board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
            {
                winner = currentPlayer;
                return true;
            }

            // Nenhum vencedor
            winner = '\0';
            return false;
        }

        private bool IsBoardFull()
        {
            foreach (var cell in board)
            {
                if (cell == '\0') return false;
            }
            return true;
        }
    }
}
