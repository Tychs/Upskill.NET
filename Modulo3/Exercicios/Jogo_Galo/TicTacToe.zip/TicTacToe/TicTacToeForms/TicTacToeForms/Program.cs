using TicTacToeLib;

namespace TicTacToeForms
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Inicializar formul�rio
            Thread formThread = new Thread(() =>
            {
                Application.SetHighDpiMode(HighDpiMode.SystemAware);
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());
            });
            formThread.SetApartmentState(ApartmentState.STA);
            formThread.Start();

            RunConsoleInterface();
        }

        static void RunConsoleInterface()
        {
            Game game = new Game();
            bool running = true;

            while (running)
            {
                Console.Clear();
                PrintBoard(game.GetBoard());

                Console.WriteLine($"Jogador Atual: {game.CurrentPlayer}");
                Console.Write("Digite a linha (0-2): ");

                if (!int.TryParse(Console.ReadLine(), out int row) || row < 0 || row > 2) 
                {
                    Console.WriteLine("Entrada Inv�lida. Tente novamente.");
                    continue;
                }

                Console.Write("Digite a coluna (0-2): ");

                if (!int.TryParse(Console.ReadLine(), out int col) || col < 0 || col > 2)
                {
                    Console.WriteLine("Entrada Inv�lida. Tente novamente.");
                    continue;
                }

                if (!game.MakeMove(row, col))
                {
                    Console.WriteLine("Movimento Inv�lido. Tente novamente.");
                    Console.ReadKey();
                    continue;
                }

                if (game.CheckWinner(out char winner))
                {
                    Console.Clear();
                    PrintBoard(game.GetBoard());
                    Console.WriteLine($"Jogado {winner} ganhou!");
                    running = false;
                }
                else if (game.IsBoardFull())
                {
                    Console.Clear();
                    PrintBoard(game.GetBoard());
                    Console.WriteLine("Empate!");
                    running = false;
                }
                else
                {
                    game.SwitchPlayer();
                }
            }

            Console.WriteLine("Pressione qualquer tecla para fechar...");
            Console.ReadKey();
        }

        static void PrintBoard(char[,] board)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(board[i, j] == '\0' ? '.' : board[i, j]);
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }
    }
}