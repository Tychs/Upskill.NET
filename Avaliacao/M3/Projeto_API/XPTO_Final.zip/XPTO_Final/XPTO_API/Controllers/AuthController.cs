﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using XPTO_API.Models;
using XPTO_Data.Entities;

namespace XPTO_API.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly XPTOContext _context;
        public AuthController(XPTOContext context) => _context = context;

        [HttpPost("register")]
        public async Task<IActionResult> RegisterLeitor([FromBody] RegisterUserRequest request)
        {
            if (request == null)
                return BadRequest("Dados inválidos.");

            byte[] passwordHash = ComputeSha256Hash(request.Password);

            var user = new User
            {
                Nome = request.Nome,
                Email = request.Email,
                Password = passwordHash,
                Role = "Leitor",
                Isactive = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(RegisterLeitor), new { id = user.IdUser }, user);
        }

        // [Authorize(Roles = "Admin")]
        [HttpPost("register-admin")]
        public async Task<IActionResult> RegisterAdmin([FromBody] RegisterUserRequest request)
        {
            if (request == null)
                return BadRequest("Dados inválidos.");

            byte[] passwordHash = ComputeSha256Hash(request.Password);

            var user = new User
            {
                Nome = request.Nome,
                Email = request.Email,
                Password = passwordHash,
                Role = "Admin",
                Isactive = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(RegisterAdmin), new { id = user.IdUser }, user);
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] XPTO_API.Models.LoginRequest request)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == request.Email);

            if (user == null || !VerifyPassword(request.Password, user.Password))
                return Unauthorized("Email ou senha inválidos.");

            var token = GenerateJwtToken(user);

            return Ok(new { Token = token });
        }

        private string GenerateJwtToken(XPTO_Data.Entities.User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("poOpNTvSKtVHFS6W7x5APnymsY6J50sw");

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] 
                { 
                    new Claim(ClaimTypes.NameIdentifier, user.IdUser.ToString()),
                    new Claim(ClaimTypes.Role, user.Role)
                }),
                Expires = DateTime.UtcNow.AddHours(2),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public static byte[] ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                return sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            }
        }

        // Método para comparar a senha inserida com a armazenada
        public static bool VerifyPassword(string inputPassword, byte[] storedHash)
        {
            byte[] inputHash = ComputeSha256Hash(inputPassword);
            return inputHash.SequenceEqual(storedHash); // Compara os arrays de bytes
        }
    }
}
