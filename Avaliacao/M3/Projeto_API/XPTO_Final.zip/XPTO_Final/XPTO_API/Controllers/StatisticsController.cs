﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using XPTO_Data.Entities;

namespace XPTO_API.Controllers
{
    [Route("api/statistics")]
    [ApiController]
    public class StatisticsController : ControllerBase
    {
        private readonly XPTOContext _context;

        public StatisticsController(XPTOContext context)
        {
            _context = context;
        }

        // Most popular obras (for purchase decisions)
        [HttpGet("popular-obras")]
        public async Task<IActionResult> GetPopularObras([FromQuery] int? limit)
        {
            var count = limit ?? 10; // Default to top 10

            var popularObras = await _context.Requisicaos
                .GroupBy(r => r.IdObra)
                .Select(g => new
                {
                    IdObra = g.Key,
                    Count = g.Count()
                })
                .OrderByDescending(x => x.Count)
                .Take(count)
                .Join(_context.Obras, r => r.IdObra, o => o.IdObra, (r, o) => new
                {
                    o.IdObra,
                    o.Titulo,
                    RequisicaoCount = r.Count
                })
                .ToListAsync();

            return Ok(popularObras);
        }

        // Nucleo performance 
        [HttpGet("nucleo-performance")]
        public async Task<IActionResult> GetNucleoPerformance()
        {
            var performance = await _context.Nucleos
                .Select(n => new
                {
                    n.IdNucleo,
                    n.Nome,
                    ObraCount = _context.ObraNucleos.Count(on => on.IdNucleo == n.IdNucleo),
                    RequisicaoCount = _context.Requisicaos.Count(r => r.IdNucleo == n.IdNucleo)
                })
                .ToListAsync();

            return Ok(performance);
        }

        // Reading suggestions based on user history
        [HttpGet("reading-suggestions")]
        public async Task<IActionResult> GetReadingSuggestions()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            int userId = string.IsNullOrEmpty(userIdClaim) ? 0 : int.Parse(userIdClaim);

            // Retorna as obras mais requisitadas
            var temRequisicoes = await _context.Requisicaos.AnyAsync(r => r.IdUser == userId);
            if (userId == 0 || !temRequisicoes)
            {
                var topObras = await _context.Requisicaos
                    .GroupBy(r => r.IdObra)
                    .Select(g => new
                    {
                        IdObra = g.Key,
                        NomeObra = _context.Obras.Where(o => o.IdObra == g.Key).Select(o => o.Titulo).FirstOrDefault(),
                        TotalRequisicoes = g.Count()
                    })
                    .OrderByDescending(o => o.TotalRequisicoes)
                    .Take(5)
                    .ToListAsync();

                return Ok(topObras);
            }

            // Temas das obras requisitadas
            var temasLidos = await _context.Requisicaos
                .Where(r => r.IdUser == userId)
                .SelectMany(r => _context.TemaObras
                    .Where(to => to.IdObra == r.IdObra)
                    .Select(to => to.IdTema))
                .Distinct()
                .ToListAsync();

            // Obras que tenham esses temas e que ainda não foram requisitadas
            var sugestoes = await _context.TemaObras
                .Where(to => temasLidos.Contains(to.IdTema))
                .Select(to => to.IdObra)
                .Distinct()
                .Where(idObra => !_context.Requisicaos.Any(r => r.IdUser == userId && r.IdObra == idObra))
                .Select(idObra => new
                {
                    IdObra = idObra,
                    NomeObra = _context.Obras.Where(o => o.IdObra == idObra).Select(o => o.Titulo).FirstOrDefault()
                })
                .ToListAsync();

            return Ok(sugestoes);
        }
    }
}