﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using XPTO_API.Models;
using XPTO_Data.Entities;

namespace XPTO_API.Controllers
{
    [Route("api/admin")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly XPTOContext _context;
        public AdminController(XPTOContext context) => _context = context;

        // Gerir Leitores
        // Suspender qualquer user pelo ID
        [HttpPut("leitores/{id}/suspender")]
        public async Task<IActionResult> SuspenderLeitor(int id)
        {
            var leitor = await _context.Users.FindAsync(id);
            if (leitor == null) return NotFound();
            leitor.Isactive = false;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Suspender user com >3 devoluções atrasadas
        [HttpPut("leitores/suspender")]
        public async Task<IActionResult> SuspenderLeitores()
        {
            try
            {
                var usersSuspender = await _context.Requisicaos
                    .Where(r => EF.Functions.DateDiffDay(r.DataReq, r.DataDev) > 15 &&
                                r.Status == "Devolvido")
                    .GroupBy(r => r.IdUser)
                    .Where(g => g.Count() > 3)
                    .Select(g => g.Key)
                    .ToListAsync();

                if (!usersSuspender.Any())
                {
                    return Ok(new { Mensagem = "Nenhum user atende aos critérios de suspensão." });
                }

                var usersSuspensos = await _context.Users
                    .Where(u => usersSuspender.Contains(u.IdUser))
                    .ToListAsync();

                if (!usersSuspensos.Any()) return NotFound("Users não encontrados.");

                foreach (var usuario in usersSuspensos)
                {
                    usuario.Isactive = false;
                }

                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Mensagem = "Leitores suspensos com sucesso.",
                    UsuariosSuspensos = usersSuspensos.Select(u => new
                    {
                        u.IdUser,
                        u.Nome,
                        u.Email,
                        Isactive = u.Isactive ?? false
                    }).ToList()
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Erro = $"Erro ao suspender leitores: {ex.Message}" });
            }
        }


        [HttpPut("leitores/{id}/reativar")]
        public async Task<IActionResult> ReativarLeitor(int id)
        {
            var leitor = await _context.Users.FindAsync(id);
            if (leitor == null) return NotFound();
            leitor.Isactive = true;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Eliminar user pelo ID
        [HttpDelete("leitores/{id}")]
        public async Task<IActionResult> RemoverLeitor(int id)
        {
            var leitor = await _context.Users.FindAsync(id);
            if (leitor == null) return NotFound();

            var temRequisicoesAtivas = await _context.Requisicaos.AnyAsync(r => r.IdUser == id && r.DataDev == null);
            if (temRequisicoesAtivas) return BadRequest("Leitor possui requisições ativas");

            int totalRequisicoes = await _context.Requisicaos.CountAsync(r => r.IdUser == id);

            // Adicionar dados no Histórico
            var historico = new Historico
            {
                IdUser = leitor.IdUser,
                Nome = leitor.Nome,
                Email = leitor.Email,
                TotalRequisicoes = totalRequisicoes,
                DataEliminacao = DateOnly.FromDateTime(DateTime.UtcNow)
            };

            _context.Historicos.Add(historico);

            var requisicoes = await _context.Requisicaos.Where(r => r.IdUser == id).ToListAsync();
            _context.Requisicaos.RemoveRange(requisicoes);

            _context.Users.Remove(leitor);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Eliminar users inativos
        [HttpDelete("leitores/remover-inativos")]
        public async Task<IActionResult> RemoverLeitoresInativos()
        {
            var umAnoAtras = DateOnly.FromDateTime(DateTime.UtcNow.AddYears(-1));

            var leitoresInativos = await _context.Users
                .Where(u => u.Role == "Leitor")
                .GroupJoin(_context.Requisicaos,
                           u => u.IdUser,
                           r => r.IdUser,
                           (u, requisicoes) => new
                           {
                               Leitor = u,
                               TotalRequisicoes = requisicoes.Count(),
                               TemRequisicoesAtivas = requisicoes.Any(r => r.DataDev == null),
                               TemRequisicoesRecentes = requisicoes.Any(r => r.DataReq >= umAnoAtras)
                           })
                .Where(l => l.TotalRequisicoes > 0)
                .Where(l => !l.TemRequisicoesRecentes) // Apenas leitores sem requisições nos últimos 12 meses
                .ToListAsync();

            if (!leitoresInativos.Any())
                return Ok(new { Mensagem = "Nenhum leitor inativo encontrado para remoção." });

            var leitoresParaRemover = new List<User>();
            var historicosParaAdicionar = new List<Historico>();
            var requisicoesParaRemover = new List<Requisicao>();

            foreach (var leitorInfo in leitoresInativos)
            {
                if (!leitorInfo.TemRequisicoesAtivas)
                {
                    historicosParaAdicionar.Add(new Historico
                    {
                        IdUser = leitorInfo.Leitor.IdUser,
                        Nome = leitorInfo.Leitor.Nome,
                        Email = leitorInfo.Leitor.Email,
                        TotalRequisicoes = leitorInfo.TotalRequisicoes,
                        DataEliminacao = DateOnly.FromDateTime(DateTime.UtcNow)
                    });

                    var requisicoes = await _context.Requisicaos
                        .Where(r => r.IdUser == leitorInfo.Leitor.IdUser)
                        .ToListAsync();
                    requisicoesParaRemover.AddRange(requisicoes);

                    leitoresParaRemover.Add(leitorInfo.Leitor);
                }
            }

            if (!leitoresParaRemover.Any())
                return Ok(new { Mensagem = "Leitores inativos possuem requisições ativas." });

            // Remove os leitores e requisições
            _context.Requisicaos.RemoveRange(requisicoesParaRemover);
            _context.Users.RemoveRange(leitoresParaRemover);
            _context.Historicos.AddRange(historicosParaAdicionar);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                Mensagem = "Leitores inativos removidos com sucesso.",
                LeitoresRemovidos = leitoresParaRemover.Select(u => new
                {
                    u.IdUser,
                    u.Nome,
                    u.Email
                }).ToList()
            });
        }


        // Gerir Obras
        [HttpPost("obras")]
        public async Task<IActionResult> AdicionarObra([FromBody] ObraRequest request)
        {
            // Criar a obra no banco
            var obra = new XPTO_Data.Entities.Obra
            {
                Titulo = request.Titulo,
                Autor = request.Autor,
                Sinopse = request.Sinopse
            };

            _context.Obras.Add(obra);
            await _context.SaveChangesAsync();

            // Adicionar os temas
            if (request.IdTemas != null && request.IdTemas.Any())
            {
                foreach (var temaId in request.IdTemas)
                {
                    var tema = await _context.Temas.FindAsync(temaId);
                    if (tema != null)
                    {
                        _context.TemaObras.Add(new XPTO_Data.Entities.TemaObra
                        {
                            IdObra = obra.IdObra,
                            IdTema = tema.IdTema
                        });
                    }
                    else
                    {
                        return BadRequest($"Tema com ID {temaId} não encontrado.");
                    }
                }
                await _context.SaveChangesAsync();
            }

            if (!string.IsNullOrEmpty(request.CapaBase64))
            {
                try
                {
                    // Converter string Base64 em bytes
                    var capaBytes = Convert.FromBase64String(request.CapaBase64);
                    var novaCapa = new XPTO_Data.Entities.Capa { Capa1 = capaBytes };

                    _context.Capas.Add(novaCapa);
                    await _context.SaveChangesAsync();

                    // Criar relação N:N entre a obra e a capa
                    _context.ObrasCapas.Add(new XPTO_Data.Entities.ObrasCapa
                    {
                        IdObra = obra.IdObra,
                        IdCapa = novaCapa.IdCapa
                    });
                    await _context.SaveChangesAsync();
                }
                catch (FormatException)
                {
                    return BadRequest("Formato de capa Base64 inválido.");
                }
            }

            // Retorna a obra criada
            return CreatedAtAction(nameof(AdicionarObra), new { id = obra.IdObra }, obra);
        }

        [HttpPut("obras/{id}")]
        public async Task<IActionResult> AlterarObra(int id, ObraUpdate obraAtualizada)
        {
            var obra = await _context.Obras.FindAsync(id);
            if (obra == null) return NotFound();

            obra.Titulo = obraAtualizada.Titulo;
            obra.Autor = obraAtualizada.Autor;
            obra.Sinopse = obraAtualizada.Sinopse;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("obras/{id}")]
        public async Task<IActionResult> RemoverObra(int id)
        {
            var obra = await _context.Obras.FindAsync(id);
            if (obra == null) return NotFound();

            var obraNucleos = await _context.ObraNucleos.Where(on => on.IdObra == id).ToListAsync();
            _context.ObraNucleos.RemoveRange(obraNucleos);

            var obraCapas = await _context.ObrasCapas.Where(oc => oc.IdObra == id).ToListAsync();
            _context.ObrasCapas.RemoveRange(obraCapas);

            // Remover as associações na tabela 'TemaObra'
            var temaObras = await _context.TemaObras.Where(to => to.IdObra == id).ToListAsync();
            _context.TemaObras.RemoveRange(temaObras);

            // Verificar se há requisições ativas para essa obra
            var requisicoesAtivas = await _context.Requisicaos.AnyAsync(r => r.IdObra == id && r.DataDev == null);
            if (requisicoesAtivas)
            {
                return BadRequest("A obra possui requisições ativas e não pode ser excluída.");
            }

            _context.Obras.Remove(obra);

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost("obras/{idObra}/transferir")]
        public async Task<IActionResult> TransferirExemplares(int idObra, int idNucleoOrigem, int idNucleoDestino, int quantidade)
        {
            var obraNucleos = await _context.ObraNucleos
                .Where(on => on.IdObra == idObra && (on.IdNucleo == idNucleoOrigem || on.IdNucleo == idNucleoDestino))
                .ToListAsync();

            var obraNucleoOrigem = obraNucleos.FirstOrDefault(on => on.IdNucleo == idNucleoOrigem);
            var obraNucleoDestino = obraNucleos.FirstOrDefault(on => on.IdNucleo == idNucleoDestino);

            // Verificar se há exemplares suficientes no núcleo de origem
            if (obraNucleoOrigem == null || obraNucleoOrigem.Exemplares <= 1 || (obraNucleoOrigem.Exemplares - quantidade) < 1)
            {
                return BadRequest(new { Erro = "Cada núcleo deve ter pelo menos 1 exemplar da obra." });
            }

            // Subtrair exemplares do núcleo de origem
            obraNucleoOrigem.Exemplares -= quantidade;

            if (obraNucleoDestino == null)
            {
                // Criar novo registo se ainda não existir
                obraNucleoDestino = new ObraNucleo
                {
                    IdObra = idObra,
                    IdNucleo = idNucleoDestino,
                    Exemplares = quantidade
                };
                _context.ObraNucleos.Add(obraNucleoDestino);
            }
            else
            {
                // Atualizar a quantidade existente
                obraNucleoDestino.Exemplares += quantidade;
            }

            await _context.SaveChangesAsync();

            var resultado = await _context.ObraNucleos
                .Where(on => on.IdObra == idObra && (on.IdNucleo == idNucleoOrigem || on.IdNucleo == idNucleoDestino))
                .Join(_context.Nucleos, on => on.IdNucleo, n => n.IdNucleo, (on, n) => new
                {
                    Nucleo = n.Nome,
                    Exemplares = on.Exemplares
                })
                .ToListAsync();

            return Ok(resultado);
        }

        [HttpPut("obras/atualizar-exemplares/{idObra}")]
        public async Task<IActionResult> AtualizarExemplares(int idObra, int idNucleo, int exemplares)
        {
            var obraNucleo = await _context.ObraNucleos
                .FirstOrDefaultAsync(on => on.IdObra == idObra && on.IdNucleo == idNucleo);

            if (obraNucleo == null)
            {
                return NotFound("A obra não foi encontrada neste núcleo.");
            }

            obraNucleo.Exemplares = exemplares;
            await _context.SaveChangesAsync();

            return NoContent(); // Retorna 204 sem conteúdo
        }

        //Gerir Requisicoes
        [HttpPost("nova-requisicao")]
        public async Task<IActionResult> CriarRequisicaoAdmin([FromBody] RequisicaoRequest requisicaoDto)
        {
            // Verifica se o usuário está ativo
            var user = await _context.Users.FindAsync(requisicaoDto.IdUser);
            if (user == null || user.Isactive == false)
            {
                return BadRequest("O user não está ativo e não pode realizar requisições.");
            }

            //Verifica se já tem 4 exemplares ativos
            int livrosRequisitados = await _context.Requisicaos
                .CountAsync(r => r.IdUser == requisicaoDto.IdUser && r.Status == "Ativo");

            if (livrosRequisitados >= 4)
                return BadRequest("O leitor já tem o número máximo de 4 exemplares requisitados.");

            //Verifica se há exemplares disponíveis no núcleo
            var obraNucleo = await _context.ObraNucleos
                .FirstOrDefaultAsync(on => on.IdObra == requisicaoDto.IdObra && on.IdNucleo == requisicaoDto.IdNucleo);

            if (obraNucleo == null || obraNucleo.Exemplares <= 1)
                return BadRequest("Não há exemplares disponíveis para requisição.");

            var novaRequisicao = new Requisicao
            {
                IdUser = requisicaoDto.IdUser,
                IdObra = requisicaoDto.IdObra,
                IdNucleo = requisicaoDto.IdNucleo,
                DataReq = DateOnly.FromDateTime(DateTime.Now),
                Status = "Ativo"
            };

            _context.Requisicaos.Add(novaRequisicao);
            obraNucleo.Exemplares--;

            await _context.SaveChangesAsync();
            return Ok("Requisição criada com sucesso!");
        }

        [HttpPut("devolver-requisicao/{idRequisicao}")]
        public async Task<IActionResult> DevolverRequisicaoAdmin(int idRequisicao)
        {
            var requisicao = await _context.Requisicaos.FindAsync(idRequisicao);
            if (requisicao == null || requisicao.Status != "Ativo")
                return NotFound("Requisição não encontrada ou já devolvida.");

            requisicao.Status = "Devolvido";
            requisicao.DataDev = DateOnly.FromDateTime(DateTime.Now);

            var obraNucleo = await _context.ObraNucleos
            .FirstOrDefaultAsync(on => on.IdObra == requisicao.IdObra && on.IdNucleo == requisicao.IdNucleo);

            if (obraNucleo != null)
                obraNucleo.Exemplares++;

            await _context.SaveChangesAsync();
            return Ok("Livro devolvido com sucesso!");
        }

        //Todas as requisições (ativas e devolvidas)
        [HttpGet("requisicoes")]
        public async Task<List<Dictionary<string, object>>> GetAllRequisicoes(DateOnly? dataInicio, DateOnly? dataFim, int? idNucleo)
        {
            return await _context.Requisicaos
                .Where(r => (!dataInicio.HasValue || r.DataReq >= dataInicio.Value) &&
                            (!dataFim.HasValue || r.DataReq <= dataFim.Value) &&
                            (!idNucleo.HasValue || r.IdNucleo == idNucleo))
                .Join(_context.Nucleos, r => r.IdNucleo, n => n.IdNucleo, (r, n) => new { r, n })
                .Join(_context.Obras, rn => rn.r.IdObra, o => o.IdObra, (rn, o) => new { rn, o })
                .Join(_context.Users, rno => rno.rn.r.IdUser, u => u.IdUser, (rno, u) => new
                {
                    Nucleo = rno.rn.n.Nome,
                    Obra = rno.o.Titulo,
                    Leitor = u.Nome,
                    DataRequisicao = rno.rn.r.DataReq,
                    DataDevolucao = rno.rn.r.DataDev,
                    Status = rno.rn.r.Status == "Ativo" ? "Ativa" : "Devolvida"
                })
                .OrderBy(r => r.Nucleo)
                .ThenBy(r => r.DataRequisicao)
                .Select(r => new Dictionary<string, object>
                {
                { "Nucleo", r.Nucleo },
                { "Obra", r.Obra },
                { "Leitor", r.Leitor },
                { "DataRequisicao", r.DataRequisicao },
                { "DataDevolucao", r.DataDevolucao },
                { "Status", r.Status }
                })
                .ToListAsync();
        }

        //Histórico de Requisições (apenas devolvidas)
        [HttpGet("historico-requisicoes")]
        public async Task<List<Dictionary<string, object>>> GetHistoricoRequisicoes(int? idNucleo, DateTime? dataReq)
        {
            var requisicoesQuery = _context.Requisicaos
                .Where(r => r.Status == "Devolvido");

            if (idNucleo.HasValue)
                requisicoesQuery = requisicoesQuery.Where(r => r.IdNucleo == idNucleo.Value);

            if (dataReq.HasValue)
            {
                var dataReqOnly = DateOnly.FromDateTime(dataReq.Value);
                requisicoesQuery = requisicoesQuery.Where(r => r.DataReq == dataReqOnly);
            }

            var requisicoes = await (from r in requisicoesQuery
                                     join o in _context.Obras on r.IdObra equals o.IdObra
                                     join u in _context.Users on r.IdUser equals u.IdUser
                                     join n in _context.Nucleos on r.IdNucleo equals n.IdNucleo
                                     select new
                                     {
                                         o.Titulo,
                                         NomeUsuario = u.Nome,
                                         DataReq = r.DataReq,
                                         NucleoNome = n.Nome,
                                         r.DataDev,
                                         DataLimite = r.DataReq.ToDateTime(TimeOnly.MinValue).AddDays(15)
                                     }).ToListAsync();

            return requisicoes.Select(r =>
            {
                bool atraso = r.DataDev.HasValue && r.DataDev.Value.ToDateTime(TimeOnly.MinValue) > r.DataLimite;
                return new Dictionary<string, object>
            {
                { "Titulo", r.Titulo },
                { "Leitor", r.NomeUsuario },
                { "Nucleo", r.NucleoNome },
                { "DataReq", r.DataReq.ToString("yyyy-MM-dd") },
                { "DataDev", r.DataDev.HasValue ? r.DataDev.Value.ToString("yyyy-MM-dd") : "Data não disponível" },
                { "Entrega", atraso ? "Atrasado" : "No Prazo" }
            };
            }).ToList();
        }

        //Status das Requisições (filtra por urgência)
        [HttpGet("status-requisicoes")]
        public async Task<List<Dictionary<string, object>>> GetStatusRequisicoes(int? idNucleo, string urgencyFilter = null)
        {
            var requisicoesQuery = _context.Requisicaos
                .Where(r => r.Status == "Ativo");

            if (idNucleo.HasValue)
                requisicoesQuery = requisicoesQuery.Where(r => r.IdNucleo == idNucleo.Value);

            var requisicoes = await (from r in requisicoesQuery
                                     join o in _context.Obras on r.IdObra equals o.IdObra
                                     join u in _context.Users on r.IdUser equals u.IdUser
                                     join n in _context.Nucleos on r.IdNucleo equals n.IdNucleo
                                     select new
                                     {
                                         o.Titulo,
                                         u.Nome,
                                         DataReq = r.DataReq,
                                         NucleoNome = n.Nome,
                                         DataLimiteDevolucao = r.DataReq.AddDays(15)
                                     }).ToListAsync();

            var allResults = requisicoes.Select(r => new Dictionary<string, object>
        {
            { "Titulo", r.Titulo },
            { "Leitor", r.Nome },
            { "Status", GetStatus(r.DataReq) },
            { "Nucleo", r.NucleoNome },
            { "DataReq", r.DataReq.ToString("yyyy-MM-dd") },
            { "DataLimiteDevolucao", r.DataLimiteDevolucao.ToString("yyyy-MM-dd") }
        }).ToList();

            if (!string.IsNullOrEmpty(urgencyFilter))
                allResults = allResults.Where(r => r["Status"].ToString() == urgencyFilter).ToList();

            return allResults;
        }

        //Método auxiliar para calcular status de urgência
        private string GetStatus(DateOnly dataReq)
        {
            DateTime dataAtual = DateTime.Now.Date;
            DateTime dataLimite = dataReq.AddDays(15).ToDateTime(TimeOnly.MinValue);
            int diasRestantes = (dataLimite - dataAtual).Days;

            if (diasRestantes < 0) return "ATRASO";
            if (diasRestantes <= 2) return "Devolução URGENTE";
            if (diasRestantes <= 5) return "Devolver Em Breve";
            return "No Prazo";
        }
    }
}
