﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XPTO_API.Models;
using XPTO_Data.Entities;
using XPTO_Data;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace XPTO_API.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly string _connectionString = "Server=localhost;Database=XPTO_Final;Trusted_Connection=True;TrustServerCertificate=True";

        [HttpGet("obras")]
        public async Task<IActionResult> GetObras()
        {
            var obras = new List<XPTO_Data.Entities.Obra>();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("SELECT * FROM Obras", connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        obras.Add(new XPTO_Data.Entities.Obra
                        {
                            IdObra = reader.GetInt32(0),
                            Titulo = reader.GetString(1),
                            Autor = reader.GetString(2),
                            Sinopse = reader.IsDBNull(3) ? null : reader.GetString(3)
                        });
                    }
                }
            }
            return Ok(obras);
        }

        [HttpGet("obras-disponiveis")]
        public async Task<IActionResult> GetObrasDisponiveisPorNucleo()
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            var query = @"
                SELECT n.Nome AS Nucleo, o.ID_Obra, o.Titulo, onl.Exemplares
                FROM Nucleos n
                JOIN ObraNucleo onl ON n.ID_Nucleo = onl.ID_Nucleo
                JOIN Obras o ON onl.ID_Obra = o.ID_Obra
                ORDER BY n.ID_Nucleo, o.Titulo;";

            using var command = new SqlCommand(query, connection);
            using var reader = await command.ExecuteReaderAsync();

            var resultado = new Dictionary<string, List<object>>();

            while (await reader.ReadAsync())
            {
                var nomeNucleo = reader["Nucleo"].ToString();
                var obra = new
                {
                    IdObra = (int)reader["ID_Obra"],
                    Titulo = reader["Titulo"].ToString(),
                    Exemplares = (int)reader["Exemplares"]
                };

                if (!resultado.ContainsKey(nomeNucleo))
                    resultado[nomeNucleo] = new List<object>();

                resultado[nomeNucleo].Add(obra);
            }

            return Ok(resultado);
        }


        [Authorize]
        [HttpDelete("cancelar-inscricao")]
        public async Task<IActionResult> CancelarInscricao()
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // ID autenticado pelo token JWT
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            // Verificar se tem requisições ativas
            using var commandCheck = new SqlCommand(
                "SELECT COUNT(*) FROM Requisicao WHERE ID_User = @IdUser AND Status = 'Ativo'", connection);
            commandCheck.Parameters.AddWithValue("@IdUser", userId);

            int requisicoesAtivas = (int)await commandCheck.ExecuteScalarAsync();

            if (requisicoesAtivas > 0)
            {
                return BadRequest("Não pode cancelar a inscrição pois ainda tem exemplares para devolver.");
            }

            using var commandDeleteUser = new SqlCommand("DELETE FROM Users WHERE ID_User = @IdUser", connection);
            commandDeleteUser.Parameters.AddWithValue("@IdUser", userId);
            await commandDeleteUser.ExecuteNonQueryAsync();

            return Ok("Inscrição cancelada com sucesso.");
        }

        [Authorize]
        [HttpPost("nova-requisicao")]
        public async Task<IActionResult> CriarRequisicao([FromBody] RequisicaoRequestUser request)
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // ID autenticado pelo JWT
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            // Verificar se o usuário está ativo
            using var commandCheckUser = new SqlCommand(
                "SELECT IsActive FROM Users WHERE ID_User = @IdUser", connection);
            commandCheckUser.Parameters.AddWithValue("@IdUser", userId);

            object? isActiveObj = await commandCheckUser.ExecuteScalarAsync();
            bool isActive = isActiveObj != null && Convert.ToBoolean(isActiveObj);

            // Verificar quantos exemplares já requisitou
            using var commandCheck = new SqlCommand(
                "SELECT COUNT(*) FROM Requisicao WHERE ID_User = @IdUser AND Status = 'Ativo'", connection);
            commandCheck.Parameters.AddWithValue("@IdUser", userId);

            int totalRequisicoes = (int)await commandCheck.ExecuteScalarAsync();
            if (totalRequisicoes >= 4)
            {
                return BadRequest("Já atingiu o limite de 4 exemplares requisitados.");
            }

            // Atualizar exemplares
            using var commandUpdateStock = new SqlCommand(
                "UPDATE ObraNucleo SET Exemplares = Exemplares - 1 WHERE ID_Obra = @IdObra AND ID_Nucleo = @IdNucleo AND Exemplares > 0",
                connection);
            commandUpdateStock.Parameters.AddWithValue("@IdObra", request.IdObra);
            commandUpdateStock.Parameters.AddWithValue("@IdNucleo", request.IdNucleo);

            int rowsAffected = await commandUpdateStock.ExecuteNonQueryAsync();
            if (rowsAffected == 0)
            {
                return BadRequest("Não há exemplares disponíveis desta obra no núcleo selecionado.");
            }

            // Criar requisição
            using var commandInsert = new SqlCommand(
                "INSERT INTO Requisicao (ID_User, ID_Obra, ID_Nucleo, DataReq, Status) VALUES (@IdUser, @IdObra, @IdNucleo, GETDATE(), 'Ativo')", connection);
            commandInsert.Parameters.AddWithValue("@IdUser", userId);
            commandInsert.Parameters.AddWithValue("@IdObra", request.IdObra);
            commandInsert.Parameters.AddWithValue("@IdNucleo", request.IdNucleo);

            await commandInsert.ExecuteNonQueryAsync();

            return Ok("Requisição realizada com sucesso.");
        }

        [Authorize]
        [HttpPut("devolver-requisicao/{idRequisicao}")]
        public async Task<IActionResult> DevolverRequisicao(int idRequisicao)
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            // Verifica se a requisição pertence ao user autenticado e se ainda está ativa
            using var commandCheck = new SqlCommand(
                "SELECT COUNT(*) FROM Requisicao WHERE ID_Requisicao = @IdRequisicao AND ID_User = @IdUser AND Status = 'Ativo'",
                connection);
            commandCheck.Parameters.AddWithValue("@IdRequisicao", idRequisicao);
            commandCheck.Parameters.AddWithValue("@IdUser", userId);

            var count = (int)await commandCheck.ExecuteScalarAsync();
            if (count == 0)
            {
                return NotFound("Requisição não encontrada ou já devolvida.");
            }

            // Atualiza o status para 'Devolvido' e define a DataDev para a data atual
            using var commandUpdate = new SqlCommand(
                "UPDATE Requisicao SET Status = 'Devolvido', DataDev = GETDATE() WHERE ID_Requisicao = @IdRequisicao AND ID_User = @IdUser",
                connection);
            commandUpdate.Parameters.AddWithValue("@IdRequisicao", idRequisicao);
            commandUpdate.Parameters.AddWithValue("@IdUser", userId);

            await commandUpdate.ExecuteNonQueryAsync();
            return Ok("Requisição devolvida com sucesso.");
        }

        [Authorize]
        [HttpGet("minhas-requisicoes")]
        public async Task<IActionResult> GetRequisicoesUser()
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // ID autenticado pelo JWT
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            using var command = new SqlCommand(
                @"SELECT r.ID_Requisicao, 
                     r.DataReq, 
                     r.DataDev, 
                     r.Status, 
                     o.ID_Obra, 
                     o.Titulo AS NomeObra, 
                     n.ID_Nucleo, 
                     n.Nome AS NomeNucleo
                FROM Requisicao r
                INNER JOIN Obras o ON r.ID_Obra = o.ID_Obra
                INNER JOIN Nucleos n ON r.ID_Nucleo = n.ID_Nucleo
                WHERE r.ID_User = @IdUser",
                connection);
            command.Parameters.AddWithValue("@IdUser", userId);

            using var reader = await command.ExecuteReaderAsync();

            var requisicoes = new List<object>();

            while (await reader.ReadAsync())
            {
                requisicoes.Add(new
                {
                    IdRequisicao = reader.GetInt32(0),
                    DataReq = reader.GetDateTime(1),  
                    DataDev = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2),
                    Status = reader.GetString(3),
                    IdObra = reader.GetInt32(4),
                    NomeObra = reader.GetString(5),
                    IdNucleo = reader.GetInt32(6),
                    NomeNucleo = reader.GetString(7)
                });
            }

            return Ok(requisicoes);
        }

    }
}
