﻿namespace XPTO_API.Models
{
    public class ObraModel
    {
        public int IdObra { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string? Sinopse { get; set; }
    }
}
