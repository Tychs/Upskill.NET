﻿namespace XPTO_API.Models
{
    public class ObraUpdate
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Sinopse { get; set; }
    }
}