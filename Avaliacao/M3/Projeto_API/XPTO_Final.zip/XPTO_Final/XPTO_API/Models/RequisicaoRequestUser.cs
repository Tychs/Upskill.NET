﻿namespace XPTO_API.Models
{
    public class RequisicaoRequestUser
    {
        public int IdObra { get; set; }
        public int IdNucleo { get; set; }
    }
}
