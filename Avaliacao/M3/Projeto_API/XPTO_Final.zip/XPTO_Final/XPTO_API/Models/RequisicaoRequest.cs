﻿namespace XPTO_API.Models
{
    public class RequisicaoRequest
    {
        public int IdUser { get; set; }
        public int IdObra { get; set; }
        public int IdNucleo { get; set; }
    }
}
