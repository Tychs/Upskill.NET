﻿namespace XPTO_API.Models
{
    public class ObraRequest
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Sinopse { get; set; }
        public List<int> IdTemas { get; set; }
        public string? CapaBase64 { get; set; }  
    }
}
