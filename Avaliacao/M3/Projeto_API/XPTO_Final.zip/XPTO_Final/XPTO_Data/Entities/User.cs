﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace XPTO_Data.Entities;

public partial class User
{
    public int IdUser { get; set; }

    public string Nome { get; set; } = null!;

    public string Role { get; set; } = null!;

    public string Email { get; set; } = null!;

    public byte[] Password { get; set; } = null!;

    public bool? Isactive { get; set; }

    public virtual ICollection<Requisicao> Requisicaos { get; set; } = new List<Requisicao>();
}