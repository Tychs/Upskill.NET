﻿using System;
using System.Collections.Generic;

namespace XPTO_Data.Entities;

public partial class ObraNucleo
{
    public int IdObra { get; set; }

    public int IdNucleo { get; set; }

    public int? Exemplares { get; set; }

    public virtual Nucleo IdNucleoNavigation { get; set; } = null!;

    public virtual Obra IdObraNavigation { get; set; } = null!;
}
