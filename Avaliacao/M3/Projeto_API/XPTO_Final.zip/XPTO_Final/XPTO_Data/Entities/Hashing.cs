﻿using System.Security.Cryptography;
using System.Text;

namespace XPTO_Data.Helpers
{
    public static class HashingHelper
    {
        // Converte string para hash em byte[]
        public static byte[] ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                return sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            }
        }

        // Método para comparar a senha inserida com a armazenada
        public static bool VerifyPassword(string inputPassword, byte[] storedHash)
        {
            byte[] inputHash = ComputeSha256Hash(inputPassword);
            return inputHash.SequenceEqual(storedHash); // Compara os arrays de bytes
        }
    }
}
