﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace XPTO_Data.Entities;

public partial class Requisicao
{
    public int IdRequisicao { get; set; }

    public int IdUser { get; set; }

    public int IdObra { get; set; }

    public int IdNucleo { get; set; }

    public DateOnly DataReq { get; set; }

    public DateOnly? DataDev { get; set; }

    public string? Status { get; set; }

    public virtual Nucleo IdNucleoNavigation { get; set; } = null!;

    public virtual Obra IdObraNavigation { get; set; } = null!;

    public virtual User IdUserNavigation { get; set; } = null!;
}
