﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace XPTO_Data.Entities;

public partial class Tema
{
    public int IdTema { get; set; }

    public string NomeTema { get; set; } = null!;

    public virtual ICollection<Obra> IdObras { get; set; } = new List<Obra>();
}
