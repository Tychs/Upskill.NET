﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace XPTO_Data.Entities;

public partial class Obra
{
    public int IdObra { get; set; }

    public string Titulo { get; set; } = null!;

    public string Autor { get; set; } = null!;

    public string? Sinopse { get; set; }

    public virtual ICollection<ObraNucleo> ObraNucleos { get; set; } = new List<ObraNucleo>();

    public virtual ICollection<Requisicao> Requisicaos { get; set; } = new List<Requisicao>();

    public virtual ICollection<Capa> IdCapas { get; set; } = new List<Capa>();

    public virtual ICollection<Tema> IdTemas { get; set; } = new List<Tema>();
}
