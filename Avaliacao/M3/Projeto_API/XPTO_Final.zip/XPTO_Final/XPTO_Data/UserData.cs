﻿using System;
using System.Data;
using System.Data.SqlClient;

public class UserData
{
    private readonly string _connectionString;

    public UserData(string connectionString)
    {
        _connectionString = connectionString;
    }

    public SqlConnection GetConnection()
    {
        // Retorna uma nova instância de SqlConnection usando a string de conexão
        return new SqlConnection(_connectionString);
    }


    // Método para obter dados do usuário
    public UserModel GetUserById(int userId)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("SELECT Id, Name, Email FROM Users WHERE Id = @Id", connection);
            command.Parameters.AddWithValue("@Id", userId);

            connection.Open();
            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    return new UserModel
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Email = reader.GetString(2)
                    };
                }
            }
        }

        return null; // Usuário não encontrado
    }

    // Método para autenticar o login do usuário
    public UserModel GetUserByEmailAndPassword(string email, string password)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("SELECT Id, Name, Email FROM Users WHERE Email = @Email AND Password = @Password", connection);
            command.Parameters.AddWithValue("@Email", email);
            command.Parameters.AddWithValue("@Password", password);  // Senha sem criptografar para simplicidade

            connection.Open();
            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    return new UserModel
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Email = reader.GetString(2)
                    };
                }
            }
        }

        return null; // Credenciais inválidas
    }

    public byte[] GetImageByObra(int idObra)
    {
        using (var connection = GetConnection())
        {
            // Consulta que faz o join entre Capas e Obras_Capas para retornar a imagem da capa.
            string query = @"
            SELECT c.Capa 
            FROM Capas c
            INNER JOIN Obras_Capas oc ON c.ID_Capa = oc.ID_Capa
            WHERE oc.ID_Obra = @ID_Obra";

            using (var command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@ID_Obra", idObra);
                connection.Open();
                var result = command.ExecuteScalar();
                return result as byte[];
            }
        }
    }

}

public class UserModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }  // Senha em texto plano (recomenda-se criptografar em produção)
}

public class ObraViewModel
{
    public int IdObra { get; set; }
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public string? Sinopse { get; set; }
    public string CapaBase64 { get; set; }
}


public class Usuario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public bool IsActive { get; set; }
    }

    public class Requisicao
    {
        public int IdRequisicao { get; set; }
        public int IdUser { get; set; }
        public int IdObra { get; set; }
        public int IdNucleo { get; set; }
        public DateTime DataReq { get; set; }
        public DateTime? DataDev { get; set; }
        public string Status { get; set; }
    }

    public class Obra
    {
        public int IdObra { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public int AnoPublicacao { get; set; }
    }
