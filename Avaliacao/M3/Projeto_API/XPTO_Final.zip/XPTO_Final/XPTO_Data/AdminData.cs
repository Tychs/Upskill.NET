﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XPTO_Data.Entities;
using XPTO_Data.Helpers;

namespace XPTO_Data
{
    public class AdminData
    {
        public readonly XPTOContext _context;

        public AdminData(XPTOContext context)
        {
            _context = context;
        }

        public async Task<User?> ValidateLoginAsync(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            if (user == null)
                return null; // Usuário não encontrado

            bool passwordMatch = HashingHelper.VerifyPassword(password, user.Password);

            return passwordMatch ? user : null;
        }

        public async Task<bool> RegisterUser(string email, string password, string nome, string role)
        {
            var hashedPassword = HashingHelper.ComputeSha256Hash(password); // Hasheia a senha

            var newUser = new User
            {
                Email = email,
                Nome = nome,
                Role = role,
                Password = hashedPassword, // Salva como byte[]
                Isactive = true
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            return true;
        }


        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _context.Users
                .Select(u => new User
                {
                    IdUser = u.IdUser,
                    Nome = u.Nome,
                    Email = u.Email,
                    Isactive = u.Isactive
                })
                .ToListAsync();
        }

        public async Task<List<Dictionary<string, object>>> GetStatusRequisicoesAsync(int? idNucleo, string urgencyFilter)
        {
            var requisicoesQuery = _context.Requisicaos.AsQueryable();

            // Filtro por idNucleo, se fornecido
            if (idNucleo.HasValue)
            {
                requisicoesQuery = requisicoesQuery.Where(r => r.IdNucleo == idNucleo.Value);
            }

            // Sempre filtramos apenas requisições ativas
            requisicoesQuery = requisicoesQuery.Where(r => r.Status == "Ativo");

            var requisicoes = await (from r in requisicoesQuery
                                     join o in _context.Obras on r.IdObra equals o.IdObra
                                     join u in _context.Users on r.IdUser equals u.IdUser
                                     join n in _context.Nucleos on r.IdNucleo equals n.IdNucleo
                                     select new
                                     {
                                         o.Titulo,
                                         u.Nome,
                                         DataReq = r.DataReq,
                                         NucleoNome = n.Nome,
                                         DataLimiteDevolucao = r.DataReq.AddDays(15)
                                     }).ToListAsync();

            Console.WriteLine("Raw Query Results:");
            foreach (var req in requisicoes)
            {
                Console.WriteLine($"Titulo: {req.Titulo}, Leitor: {req.Nome}, DataReq: {req.DataReq}, Nucleo: {req.NucleoNome}, DataLimiteDevolucao: {req.DataLimiteDevolucao}");
            }

            // Processamento dos dados e cálculo do status de urgência
            var allResults = requisicoes.Select(r => new Dictionary<string, object>
            {
                { "Titulo", r.Titulo },
                { "Leitor", r.Nome },
                { "Status", GetStatus(r.DataReq) },
                { "Nucleo", r.NucleoNome },
                { "DataReq", r.DataReq.ToString("yyyy-MM-dd") },
                { "DataLimiteDevolucao", r.DataLimiteDevolucao.ToString("yyyy-MM-dd") }
            }).ToList();

            // Filtro por nível de urgência, se fornecido
            if (!string.IsNullOrEmpty(urgencyFilter))
            {
                allResults = allResults.Where(r => r["Status"].ToString() == urgencyFilter).ToList();
            }

            return allResults;
        }

        public async Task<List<Dictionary<string, object>>> GetHistoricoRequisicoesAsync(int? idNucleo, DateTime? dataReq)
        {
            // Filtra apenas as requisições com status "Devolvido"
            var requisicoesQuery = _context.Requisicaos.AsQueryable()
                                      .Where(r => r.Status == "Devolvido");

            // Filtro por núcleo, se informado
            if (idNucleo.HasValue)
            {
                requisicoesQuery = requisicoesQuery.Where(r => r.IdNucleo == idNucleo.Value);
            }

            // Filtro por data de requisição, se informado
            if (dataReq.HasValue)
            {
                // Converte o DateTime informado para DateOnly
                var dataReqOnly = DateOnly.FromDateTime(dataReq.Value);

                // Como r.DataReq já é DateOnly?, basta compará-lo diretamente
                requisicoesQuery = requisicoesQuery.Where(r => r.DataReq == dataReqOnly);
            }

            // Realiza a consulta com os joins necessários
            var requisicoes = await (from r in requisicoesQuery
                                     join o in _context.Obras on r.IdObra equals o.IdObra
                                     join u in _context.Users on r.IdUser equals u.IdUser
                                     join n in _context.Nucleos on r.IdNucleo equals n.IdNucleo
                                     select new
                                     {
                                         o.Titulo,
                                         NomeUsuario = u.Nome,
                                         // r.DataReq agora é DateOnly (não nullable)
                                         DataReq = r.DataReq,
                                         NucleoNome = n.Nome,
                                         r.DataDev,
                                         // Converte r.DataReq para DateTime e adiciona 15 dias
                                         DataLimite = r.DataReq.ToDateTime(TimeOnly.MinValue).AddDays(15)
                                     }).ToListAsync();

            // (Opcional) Log para depuração
            foreach (var req in requisicoes)
            {
                Console.WriteLine($"Titulo: {req.Titulo}, DataReq: {req.DataReq}, DataDev: {req.DataDev}");
            }

            // Monta a lista de resultados no formato de dicionário
            var allResults = requisicoes.Select(r =>
            {
                // Define atraso se a data de devolução for superior à data limite
                bool atraso = r.DataDev.HasValue && r.DataDev.Value.ToDateTime(TimeOnly.MinValue) > r.DataLimite;
                return new Dictionary<string, object>
        {
            { "Titulo", r.Titulo },
            { "Leitor", r.NomeUsuario },
            { "Nucleo", r.NucleoNome },
            { "DataReq", r.DataReq.ToString("yyyy-MM-dd") },
            { "DataDev", r.DataDev.HasValue ? r.DataDev.Value.ToString("yyyy-MM-dd") : "Data não disponível" },
            { "Entrega", atraso ? "Atrasado" : "No Prazo" }
        };
            }).ToList();

            return allResults;
        }




        // Método auxiliar para calcular o status de urgência
        private string GetStatus(DateOnly dataReq)
        {
            // Data atual sem considerar as horas
            DateTime dataAtual = DateTime.Now.Date;

            // Calcula a data limite de devolução (15 dias após a requisição)
            DateTime dataLimite = dataReq.AddDays(15).ToDateTime(TimeOnly.MinValue);

            // Calcula os dias restantes até a data limite (pode ser negativo se já estiver em atraso)
            int diasRestantes = (dataLimite - dataAtual).Days;

            // Já passou da data limite (está em atraso)
            if (diasRestantes < 0)
            {
                return "ATRASO";
            }

            // Faltam 2 dias ou menos para o prazo final
            if (diasRestantes <= 2)
            {
                return "Devolução URGENTE";
            }

            // Faltam entre 3 e 5 dias para o prazo final
            if (diasRestantes <= 5)
            {
                return "Devolver Em Breve";
            }

            // Ainda tem bastante tempo para devolver
            return "No Prazo";
        }

        public async Task<List<Dictionary<string, object>>> GetNucleosPorRequisicaoAsync(DateOnly? dataInicio, DateOnly? dataFim)
        {
            var nucleos = await (from n in _context.Nucleos
                                 join r in _context.Requisicaos on n.IdNucleo equals r.IdNucleo into reqGroup
                                 from r in reqGroup.DefaultIfEmpty()
                                 where (dataInicio == null || dataFim == null || (r.DataReq >= dataInicio && r.DataReq <= dataFim))
                                 group r by new { n.IdNucleo, n.Nome } into g
                                 select new
                                 {
                                     g.Key.IdNucleo,
                                     g.Key.Nome,
                                     TotalRequisicoes = g.Count(r => r != null) // Contagem das requisições válidas
                                 })
                                 .Distinct()  // Adiciona Distinct para garantir que núcleos não sejam repetidos
                                 .OrderByDescending(n => n.TotalRequisicoes)
                                 .ToListAsync();

            // Transformar a lista em dicionários (se quiser evitar classes modelo)
            var result = nucleos.Select(n => new Dictionary<string, object>
            {
                { "ID_Nucleo", n.IdNucleo },
                { "Nome", n.Nome },
                { "TotalRequisicoes", n.TotalRequisicoes }
            }).ToList();

            return result;
        }


        public async Task<bool> AddNewLeitorAsync(string nome, string email, byte[] password)
        {
            var novoLeitor = new User
            {
                Nome = nome,
                Role = "User",
                Email = email,
                Password = password, // Agora recebe diretamente como byte[]
                Isactive = true
            };

            await _context.Users.AddAsync(novoLeitor);
            await _context.SaveChangesAsync();

            return true;
        }

        // Método auxiliar para converter a senha em varbinary (simula a stored procedure)
        private byte[] ConvertPassword(string password)
        {
            return System.Text.Encoding.UTF8.GetBytes(password);
        }

        public async Task<List<Dictionary<string, object>>> GetRequisicoesAsync(DateOnly? dataInicio, DateOnly? dataFim, int? idNucleo)
        {
            return await _context.Requisicaos
                .Where(r => (!dataInicio.HasValue || r.DataReq >= dataInicio.Value) &&
                            (!dataFim.HasValue || r.DataReq <= dataFim.Value) &&
                            (!idNucleo.HasValue || r.IdNucleo == idNucleo))
                .Join(_context.Nucleos, r => r.IdNucleo, n => n.IdNucleo, (r, n) => new { r, n })
                .Join(_context.Obras, rn => rn.r.IdObra, o => o.IdObra, (rn, o) => new { rn, o })
                .Join(_context.Users, rno => rno.rn.r.IdUser, u => u.IdUser, (rno, u) => new
                {
                    Nucleo = rno.rn.n.Nome,  // Nome do Núcleo
                    Obra = rno.o.Titulo,  // Título da Obra
                    Leitor = u.Nome,  // Nome do Leitor
                    DataRequisicao = rno.rn.r.DataReq,
                    DataDevolucao = rno.rn.r.DataDev,
                    Status = rno.rn.r.Status == "Ativo" ? "Ativa" : "Devolvida"
                })
                .OrderBy(r => r.Nucleo)  // Agora o nome do Núcleo está disponível
                .ThenBy(r => r.DataRequisicao)
                .Select(r => new Dictionary<string, object>
                {
            { "Nucleo", r.Nucleo },
            { "Obra", r.Obra },
            { "Leitor", r.Leitor },
            { "DataRequisicao", r.DataRequisicao },
            { "DataDevolucao", r.DataDevolucao },
            { "Status", r.Status }
                })
                .ToListAsync();
        }

        public async Task<int> UpdateExemplaresObraAsync(int idObra, int idNucleo, int exemplares)
        {
            var obraNucleo = await _context.ObraNucleos
                .FirstOrDefaultAsync(oc => oc.IdObra == idObra && oc.IdNucleo == idNucleo);

            if (obraNucleo == null)
            {
                // Log para verificar o que aconteceu se a entrada não for encontrada
                Console.WriteLine($"Erro: Não foi encontrado registro com idObra = {idObra} e idNucleo = {idNucleo}");
                return 0;
            }

            // Se a entrada for encontrada, faz a atualização
            obraNucleo.Exemplares = exemplares;

            return await _context.SaveChangesAsync();
        }


        public async Task<List<Dictionary<string, object>>> TransferirExemplaresAsync( int idObra, int idNucleoOrigem, int idNucleoDestino, int quantidade)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Verificar se há exemplares suficientes no núcleo de origem
                var exemplaresOrigem = await _context.ObraNucleos
                    .Where(on => on.IdObra == idObra && on.IdNucleo == idNucleoOrigem)
                    .Select(on => on.Exemplares)
                    .FirstOrDefaultAsync();

                if (exemplaresOrigem == null || exemplaresOrigem < quantidade)
                {
                    return new List<Dictionary<string, object>> { new() { { "Erro", "Não é possível concluir a transferência, exemplares insuficientes." } } };
                }

                // Subtrair exemplares do núcleo de origem
                var obraNucleoOrigem = await _context.ObraNucleos
                    .FirstOrDefaultAsync(on => on.IdObra == idObra && on.IdNucleo == idNucleoOrigem);

                if (obraNucleoOrigem != null)
                {
                    obraNucleoOrigem.Exemplares -= quantidade;
                }

                // Verificar se o núcleo de destino já possui exemplares da obra
                var obraNucleoDestino = await _context.ObraNucleos
                    .FirstOrDefaultAsync(on => on.IdObra == idObra && on.IdNucleo == idNucleoDestino);

                if (obraNucleoDestino == null)
                {
                    // Criar novo registro se ainda não existir
                    _context.ObraNucleos.Add(new ObraNucleo
                    {
                        IdObra = idObra,
                        IdNucleo = idNucleoDestino,
                        Exemplares = quantidade
                    });
                }
                else
                {
                    // Atualizar a quantidade existente
                    obraNucleoDestino.Exemplares += quantidade;
                }

                await _context.SaveChangesAsync();

                // Commit da transação
                await transaction.CommitAsync();

                // Retornar os exemplares finais
                var resultado = await _context.ObraNucleos
                    .Where(on => on.IdObra == idObra && (on.IdNucleo == idNucleoOrigem || on.IdNucleo == idNucleoDestino))
                    .Join(_context.Nucleos, on => on.IdNucleo, n => n.IdNucleo, (on, n) => new Dictionary<string, object>
                    {
                    { "Nucleo", n.Nome },
                    { "Exemplares", on.Exemplares }
                    })
                    .ToListAsync();

                return resultado;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new List<Dictionary<string, object>> { new() { { "Erro", $"Erro ao transferir exemplares: {ex.Message}" } } };
            }
        }

        public async Task<List<Dictionary<string, object>>> SuspendLeitoresAsync()
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Identificar os usuários que devem ser suspensos
                var usuariosParaSuspender = await _context.Requisicaos
                    .Where(r => EF.Functions.DateDiffDay(r.DataReq, r.DataDev) > 15 &&
                                r.Status == "Devolvido")
                    .GroupBy(r => r.IdUser)
                    .Where(g => g.Count() > 3)
                    .Select(g => g.Key)
                    .ToListAsync();

                if (!usuariosParaSuspender.Any())
                {
                    return new List<Dictionary<string, object>> { new() { { "Mensagem", "Nenhum usuário atende aos critérios de suspensão." } } };
                }

                // Atualizar usuários
                var usuariosSuspensos = await _context.Users
                    .Where(u => usuariosParaSuspender.Contains(u.IdUser))
                    .ToListAsync();

                foreach (var usuario in usuariosSuspensos)
                {
                    usuario.Isactive = false; // Suspende o usuário
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Retornar os usuários suspensos
                return usuariosSuspensos.Select(u => new Dictionary<string, object>
                {
                    { "ID_User", u.IdUser },
                    { "Nome", u.Nome },
                    { "Email", u.Email },
                    { "ISACTIVE", (u.Isactive ?? false) ? "True" : "False" } // Converte para string
                        }).ToList();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new List<Dictionary<string, object>> { new() { { "Erro", $"Erro ao suspender leitores: {ex.Message}" } } };
            }
        }

        public async Task<Dictionary<string, object>> ReativarLeitorAsync(int idUser)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Verificar se o leitor está suspenso
                var usuario = await _context.Users
                    .Where(u => u.IdUser == idUser && u.Isactive == false)
                    .FirstOrDefaultAsync();

                if (usuario == null)
                {
                    return new Dictionary<string, object>
                    {
                        { "Erro", "O leitor não está suspenso ou não existe." }
                    };
                }

                // Atualizar o estado do leitor para ativo
                usuario.Isactive = true;
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Retornar informações do leitor atualizado
                return new Dictionary<string, object>
                {
                    { "ID_User", usuario.IdUser },
                    { "Nome", usuario.Nome },
                    { "Email", usuario.Email },
                    { "ISACTIVE", (usuario.Isactive ?? false) ? "True" : "False" } // Garante que valores nulos são tratados
                };
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new Dictionary<string, object>
                {
                    { "Erro", $"Erro ao reativar leitor: {ex.Message}" }
                };
            }
        }
    }
}
