﻿using System.ComponentModel.DataAnnotations;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using XPTO_Data;
using XPTO_Data.Entities;

namespace XPTO_API
{
    public class Program
    {
        // Definição das DTOs antes do app.Run()
        public class RequisicaoRequest
        {
            public int IdUser { get; set; }
            public int IdObra { get; set; }
            public int IdNucleo { get; set; }
            public DateOnly DataReq { get; set; }
        }

        public class ObraNucleoRequest
        {
            public int IdObra { get; set; }
            public int IdNucleo { get; set; }
            public int Exemplares { get; set; }
        }

        public class ObraRequest
        {
            [Required(ErrorMessage = "O título é obrigatório.")]
            [MaxLength(100, ErrorMessage = "O título não pode exceder 100 caracteres.")]
            public string Titulo { get; set; }

            [Required(ErrorMessage = "O autor é obrigatório.")]
            [MaxLength(100, ErrorMessage = "O autor não pode exceder 100 caracteres.")]
            public string Autor { get; set; }

            [MaxLength(1000, ErrorMessage = "A sinopse não pode exceder 1000 caracteres.")]
            public string Sinopse { get; set; }

            [Required(ErrorMessage = "A imagem é obrigatória.")]
            public IFormFile Imagem { get; set; }
        }


        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Configuração do banco de dados
            builder.Services.AddDbContext<XPTOContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // Adicionar AdminData ao sistema de injeção de dependências
            builder.Services.AddScoped<AdminData>();

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAllOrigins",
                    builder =>
                    {
                        builder.AllowAnyOrigin()
                               .AllowAnyMethod()
                               .AllowAnyHeader();
                    });
            });

            builder.Services.AddSwaggerGen(c =>
            {
                // Customização para o Swagger lidar com arquivos de upload
                c.MapType<IFormFile>(() => new OpenApiSchema
                {
                    Type = "string",
                    Format = "binary"
                });
            });


            var app = builder.Build();

            //app.UseHttpsRedirection();
            app.UseCors("AllowAllOrigins");

            string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

            app.MapPost("/api/admin/login", async (LoginReq loginRequest, XPTOContext context) =>
            {
                try
                {
                    // Função para verificar o hash da senha
                    bool VerifyPasswordHash(string password, byte[] storedHash)
                    {
                        using (var sha256 = System.Security.Cryptography.SHA256.Create())
                        {
                            var passwordBytes = Encoding.UTF8.GetBytes(password);
                            var hashedPassword = sha256.ComputeHash(passwordBytes);
                            return hashedPassword.SequenceEqual(storedHash);
                        }
                    }

                    if (string.IsNullOrEmpty(loginRequest.Email) || string.IsNullOrEmpty(loginRequest.Password))
                    {
                        return Results.Json(new { Message = "Email ou senha não fornecidos." }, statusCode: 400);
                    }

                    var user = await context.Users.SingleOrDefaultAsync(u => u.Email == loginRequest.Email);
                    if (user == null)
                    {
                        return Results.Json(new { Message = "Credenciais inválidas." }, statusCode: 401);
                    }

                    if (!VerifyPasswordHash(loginRequest.Password, user.Password))
                    {
                        return Results.Json(new { Message = "Credenciais inválidas." }, statusCode: 401);
                    }

                    if (user.Role != "Admin")
                    {
                        return Results.Json(new { Message = "Acesso negado: Usuário não é administrador." }, statusCode: 403);
                    }

                    return Results.Ok(new { Message = "Login bem-sucedido!", Role = user.Role, Email = user.Email });
                }
                catch (Exception ex)
                {
                    // Log da exceção (opcional)
                    Console.WriteLine($"Erro: {ex.Message}");
                    // Retorna uma resposta JSON com o erro
                    return Results.Json(new { Message = "Ocorreu um erro interno no servidor." }, statusCode: 500);
                }
            });

            // Endpoint para buscar um usuário específico pelo ID
            app.MapGet("/api/admin/usuarios/{id}", async (int id, AdminData adminData) =>
            {
                var user = await adminData._context.Users.FindAsync(id);
                return user is not null ? Results.Ok(user) : Results.NotFound("User não encontrado.");
            });

            // Endpoint para buscar usuários (Admin - EF Core)
            app.MapGet("/api/admin/usuarios", async (AdminData adminData) =>
            {
                var users = await adminData.GetAllUsersAsync();
                return Results.Ok(users);
            });

            // Endpoint para excluir usuário 
            app.MapDelete("/api/admin/usuarios/{id}", async (int id, AdminData adminData) =>
            {
                var user = await adminData._context.Users.FindAsync(id);
                if (user == null)
                {
                    return Results.NotFound("User não encontrado.");
                }

                adminData._context.Users.Remove(user);
                await adminData._context.SaveChangesAsync();
                return Results.Ok("User excluído com sucesso.");
            });

            // Endpoint para editar usuário
            app.MapPut("/api/admin/usuarios/{id}", async (int id, User updatedUser, AdminData adminData) =>
            {
                var user = await adminData._context.Users.FindAsync(id);
                if (user == null)
                {
                    return Results.NotFound("User não encontrado.");
                }

                user.Nome = updatedUser.Nome;
                user.Email = updatedUser.Email;
                user.Isactive = updatedUser.Isactive;  // Caso precise atualizar o status de ativo/desativo do usuário

                await adminData._context.SaveChangesAsync();
                return Results.Ok("User atualizado com sucesso.");
            });

            app.MapGet("/api/admin/estado-requisicoes", async (AdminData adminData, int? idNucleo, string? urgencyFilter) =>
            {
                var requisicoes = await adminData.GetStatusRequisicoesAsync(idNucleo, urgencyFilter);
                return Results.Ok(requisicoes);
            });

            app.MapGet("/api/admin/historico-requisicoes", async (AdminData adminData, int? idNucleo, string? dataRequisicao) =>
            {
                // Converte a data se for fornecida
                DateTime? dataReq = null;
                if (!string.IsNullOrEmpty(dataRequisicao) && DateTime.TryParse(dataRequisicao, out var parsedDate))
                {
                    dataReq = parsedDate;
                }

                // Obtém o histórico de requisições com os filtros de idNucleo e dataRequisicao
                var historico = await adminData.GetHistoricoRequisicoesAsync(idNucleo, dataReq);

                return Results.Ok(historico);
            });

            app.MapGet("/api/admin/nucleos-por-requisicao", async (AdminData adminData, DateOnly? dataInicio, DateOnly? dataFim) =>
            {
                var nucleos = await adminData.GetNucleosPorRequisicaoAsync(dataInicio, dataFim);
                return Results.Ok(nucleos);
            });

            app.MapPost("/api/admin/add-leitor", async (User user, AdminData adminData) =>
            {
                try
                {
                    bool success = await adminData.AddNewLeitorAsync(user.Nome, user.Email, user.Password);

                    return success ? Results.Ok("User registrado com sucesso.")
                                   : Results.BadRequest("Erro ao registrar User.");
                }
                catch (Exception ex)
                {
                    return Results.BadRequest($"Erro: {ex.Message}");
                }
            });

            app.MapGet("/api/admin/requisicoes", async (XPTOContext context, DateOnly? dataInicio, DateOnly? dataFim, int? idNucleo) =>
            {
                var adminData = new AdminData(context); // Criamos a instância do AdminData
                var requisicoes = await adminData.GetRequisicoesAsync(dataInicio, dataFim, idNucleo);
                return Results.Ok(requisicoes);
            });

            app.MapPut("/api/obra/atualizar-exemplares", async (XPTOContext db, int idObra, int idNucleo, int exemplares) =>
            {
                var adminData = new AdminData(db);
                var resultado = await adminData.UpdateExemplaresObraAsync(idObra, idNucleo, exemplares);
                return resultado > 0
                    ? Results.Ok(new { message = "Exemplares atualizados com sucesso!" })
                    : Results.BadRequest(new { message = "Não foi possível atualizar os exemplares." });
            });

            app.MapPut("/api/obra/transferir-exemplares", async (XPTOContext context, int idObra, int idNucleoOrigem, int idNucleoDestino, int quantidade) =>
            {
                var adminData = new AdminData(context); // Criamos a instância do AdminData
                var resultado = await adminData.TransferirExemplaresAsync(idObra, idNucleoOrigem, idNucleoDestino, quantidade);

                return Results.Ok(resultado);
            });

            app.MapPut("/api/admin/suspender-leitores", async (XPTOContext context) =>
            {
                var adminData = new AdminData(context); // Criar instância de AdminData
                try
                {
                    await adminData.SuspendLeitoresAsync(); // Chama o método de suspensão de leitores
                    return Results.Ok(new { message = "Leitores suspensos com sucesso!" });
                }
                catch (Exception ex)
                {
                    return Results.BadRequest(new { message = ex.Message });
                }
            });

            app.MapGet("/api/leitores/suspensos", async (XPTOContext context) =>
            {
                var suspendedUsers = await context.Users
                    .Where(u => u.Isactive == false)
                    .Select(u => new { u.IdUser, u.Nome, u.Email })
                    .ToListAsync();

                return Results.Ok(suspendedUsers);
            });

            app.MapPut("/api/leitor/reativar", async (XPTOContext context, [FromBody] Dictionary<string, int> body) =>
            {
                if (body == null || !body.ContainsKey("idUser"))
                {
                    return Results.BadRequest("Missing idUser");
                }

                var idUser = body["idUser"];
                var adminData = new AdminData(context);
                var resultado = await adminData.ReativarLeitorAsync(idUser);
                return Results.Ok(resultado);
            });

            app.MapPost("/api/obras/adicionar", async ([FromForm] ObraRequest obraRequest, AdminData adminData) =>
            {
                try
                {
                    // Manipule os dados de obraRequest diretamente, incluindo a imagem
                    var titulo = obraRequest.Titulo;
                    var autor = obraRequest.Autor;
                    var sinopse = obraRequest.Sinopse;
                    var imageFile = obraRequest.Imagem;

                    string imageFilePath = null;
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        var tempFilePath = Path.GetTempFileName();
                        using (var stream = new FileStream(tempFilePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(stream);
                        }
                        imageFilePath = tempFilePath;
                    }

                    bool success = await adminData.AddNewObraAsync(titulo, autor, sinopse, imageFilePath);

                    if (imageFilePath != null)
                    {
                        File.Delete(imageFilePath);
                    }

                    return success ? Results.Ok("Obra adicionada com sucesso.") : Results.BadRequest("Erro ao adicionar obra.");
                }
                catch (Exception ex)
                {
                    return Results.BadRequest($"Erro: {ex.Message}");
                }
            });



            app.MapPost("/api/requisicoes/adicionar", async (RequisicaoRequest requisicaoRequest, AdminData adminData) =>
            {
                try
                {
                    var detalhesRequisicao = await adminData.AddNewRequisicaoAsync(
                        requisicaoRequest.IdUser,
                        requisicaoRequest.IdObra,
                        requisicaoRequest.IdNucleo,
                        requisicaoRequest.DataReq);

                    return Results.Ok(detalhesRequisicao);
                }
                catch (Exception ex)
                {
                    return Results.BadRequest($"Erro: {ex.Message}");
                }
            });

            app.MapDelete("/api/usuarios/{idUser}/cancelar-inscricao", async (int idUser, AdminData adminData) =>
            {
                try
                {
                    var resultado = await adminData.CancelarInscricaoAsync(idUser);
                    return Results.Ok(resultado);
                }
                catch (Exception ex)
                {
                    return Results.BadRequest($"Erro: {ex.Message}");
                }
            });

            app.MapPut("/api/requisicoes/{idRequisicao}/atualizar-estado", async (int idRequisicao, string novoEstado, AdminData adminData) =>
            {
                try
                {
                    await adminData.AtualizarEstadoRequisicaoAsync(idRequisicao, novoEstado);
                    return Results.Ok("Estado da requisição atualizado com sucesso.");
                }
                catch (Exception ex)
                {
                    return Results.BadRequest($"Erro: {ex.Message}");
                }
            });

            app.MapPost("/api/obra-nucleo/adicionar", async (ObraNucleoRequest obraNucleoRequest, AdminData adminData) =>
            {
                try
                {
                    await adminData.AdicionarObraNucleoAsync(
                        obraNucleoRequest.IdObra,
                        obraNucleoRequest.IdNucleo,
                        obraNucleoRequest.Exemplares);

                    return Results.Ok("ObraNucleo adicionada com sucesso.");
                }
                catch (Exception ex)
                {
                    return Results.BadRequest($"Erro: {ex.Message}");
                }
            });



            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.Run();
        }
    }

}
