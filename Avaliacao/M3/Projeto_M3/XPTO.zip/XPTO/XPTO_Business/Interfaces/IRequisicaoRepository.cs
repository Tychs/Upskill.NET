﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XPTO_Data.Entities;

namespace XPTO_Business.Interfaces
{
    public interface IRequisicaoRepository
    {
        Task<IEnumerable<Requisicao>> GetRequisicoesByUserIdAsync(int userId);
    }
}
