﻿namespace XPTO_Business
{
    public class Class1
    {

    }
}
