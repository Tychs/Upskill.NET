﻿using Microsoft.EntityFrameworkCore;
using XPTO_Data.Entities;

namespace XPTO_Data
{
    public class AdminData
    {
        public readonly XPTOContext _context;

        public AdminData(XPTOContext context)
        {
            _context = context;
        }

        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _context.Users
                .Select(u => new User
                {
                    IdUser = u.IdUser,
                    Nome = u.Nome,
                    Email = u.Email,
                    Isactive = u.Isactive
                })
                .ToListAsync();
        }

        public async Task<List<Dictionary<string, object>>> GetStatusRequisicoesAsync(int? idNucleo, string urgencyFilter)
        {
            var requisicoesQuery = _context.Requisicaos.AsQueryable();

            // Filtro por idNucleo, se fornecido
            if (idNucleo.HasValue)
            {
                requisicoesQuery = requisicoesQuery.Where(r => r.IdNucleo == idNucleo.Value);
            }

            // Sempre filtramos apenas requisições ativas
            requisicoesQuery = requisicoesQuery.Where(r => r.Status == "Ativo");

            var requisicoes = await (from r in requisicoesQuery
                                     join o in _context.Obras on r.IdObra equals o.IdObra
                                     join u in _context.Users on r.IdUser equals u.IdUser
                                     join n in _context.Nucleos on r.IdNucleo equals n.IdNucleo
                                     select new
                                     {
                                         o.Titulo,
                                         u.Nome,
                                         DataReq = r.DataReq,
                                         NucleoNome = n.Nome,
                                         DataLimiteDevolucao = r.DataReq.AddDays(15)
                                     }).ToListAsync();

            Console.WriteLine("Raw Query Results:");
            foreach (var req in requisicoes)
            {
                Console.WriteLine($"Titulo: {req.Titulo}, Leitor: {req.Nome}, DataReq: {req.DataReq}, Nucleo: {req.NucleoNome}, DataLimiteDevolucao: {req.DataLimiteDevolucao}");
            }

            // Processamento dos dados e cálculo do status de urgência
            var allResults = requisicoes.Select(r => new Dictionary<string, object>
            {
                { "Titulo", r.Titulo },
                { "Leitor", r.Nome },
                { "Status", GetStatus(r.DataReq) },
                { "Nucleo", r.NucleoNome },
                { "DataReq", r.DataReq.ToString("yyyy-MM-dd") },
                { "DataLimiteDevolucao", r.DataLimiteDevolucao.ToString("yyyy-MM-dd") }
            }).ToList();

            // Filtro por nível de urgência, se fornecido
            if (!string.IsNullOrEmpty(urgencyFilter))
            {
                allResults = allResults.Where(r => r["Status"].ToString() == urgencyFilter).ToList();
            }

            return allResults;
        }

        public async Task<List<Dictionary<string, object>>> GetHistoricoRequisicoesAsync(int? idNucleo, DateTime? dataReq)
        {
            // Filtra apenas as requisições com status "Devolvido"
            var requisicoesQuery = _context.Requisicaos.AsQueryable()
                                      .Where(r => r.Status == "Devolvido");

            // Filtro por núcleo, se informado
            if (idNucleo.HasValue)
            {
                requisicoesQuery = requisicoesQuery.Where(r => r.IdNucleo == idNucleo.Value);
            }

            // Filtro por data de requisição, se informado
            if (dataReq.HasValue)
            {
                // Converte o DateTime informado para DateOnly
                var dataReqOnly = DateOnly.FromDateTime(dataReq.Value);

                // Como r.DataReq já é DateOnly?, basta compará-lo diretamente
                requisicoesQuery = requisicoesQuery.Where(r => r.DataReq == dataReqOnly);
            }

            // Realiza a consulta com os joins necessários
            var requisicoes = await (from r in requisicoesQuery
                                     join o in _context.Obras on r.IdObra equals o.IdObra
                                     join u in _context.Users on r.IdUser equals u.IdUser
                                     join n in _context.Nucleos on r.IdNucleo equals n.IdNucleo
                                     select new
                                     {
                                         o.Titulo,
                                         NomeUsuario = u.Nome,
                                         // r.DataReq agora é DateOnly (não nullable)
                                         DataReq = r.DataReq,
                                         NucleoNome = n.Nome,
                                         r.DataDev,
                                         // Converte r.DataReq para DateTime e adiciona 15 dias
                                         DataLimite = r.DataReq.ToDateTime(TimeOnly.MinValue).AddDays(15)
                                     }).ToListAsync();

            // (Opcional) Log para depuração
            foreach (var req in requisicoes)
            {
                Console.WriteLine($"Titulo: {req.Titulo}, DataReq: {req.DataReq}, DataDev: {req.DataDev}");
            }

            // Monta a lista de resultados no formato de dicionário
            var allResults = requisicoes.Select(r =>
            {
                // Define atraso se a data de devolução for superior à data limite
                bool atraso = r.DataDev.HasValue && r.DataDev.Value.ToDateTime(TimeOnly.MinValue) > r.DataLimite;
                return new Dictionary<string, object>
        {
            { "Titulo", r.Titulo },
            { "Leitor", r.NomeUsuario },
            { "Nucleo", r.NucleoNome },
            { "DataReq", r.DataReq.ToString("yyyy-MM-dd") },
            { "DataDev", r.DataDev.HasValue ? r.DataDev.Value.ToString("yyyy-MM-dd") : "Data não disponível" },
            { "Entrega", atraso ? "Atrasado" : "No Prazo" }
        };
            }).ToList();

            return allResults;
        }




        // Método auxiliar para calcular o status de urgência
        private string GetStatus(DateOnly dataReq)
        {
            // Data atual sem considerar as horas
            DateTime dataAtual = DateTime.Now.Date;

            // Calcula a data limite de devolução (15 dias após a requisição)
            DateTime dataLimite = dataReq.AddDays(15).ToDateTime(TimeOnly.MinValue);

            // Calcula os dias restantes até a data limite (pode ser negativo se já estiver em atraso)
            int diasRestantes = (dataLimite - dataAtual).Days;

            // Já passou da data limite (está em atraso)
            if (diasRestantes < 0)
            {
                return "ATRASO";
            }

            // Faltam 2 dias ou menos para o prazo final
            if (diasRestantes <= 2)
            {
                return "Devolução URGENTE";
            }

            // Faltam entre 3 e 5 dias para o prazo final
            if (diasRestantes <= 5)
            {
                return "Devolver Em Breve";
            }

            // Ainda tem bastante tempo para devolver
            return "No Prazo";
        }

        public async Task<List<Dictionary<string, object>>> GetNucleosPorRequisicaoAsync(DateOnly? dataInicio, DateOnly? dataFim)
        {
            var nucleos = await (from n in _context.Nucleos
                                 join r in _context.Requisicaos on n.IdNucleo equals r.IdNucleo into reqGroup
                                 from r in reqGroup.DefaultIfEmpty()
                                 where (dataInicio == null || dataFim == null || (r.DataReq >= dataInicio && r.DataReq <= dataFim))
                                 group r by new { n.IdNucleo, n.Nome } into g
                                 select new
                                 {
                                     g.Key.IdNucleo,
                                     g.Key.Nome,
                                     TotalRequisicoes = g.Count(r => r != null) // Contagem das requisições válidas
                                 })
                                 .Distinct()  // Adiciona Distinct para garantir que núcleos não sejam repetidos
                                 .OrderByDescending(n => n.TotalRequisicoes)
                                 .ToListAsync();

            // Transformar a lista em dicionários (se quiser evitar classes modelo)
            var result = nucleos.Select(n => new Dictionary<string, object>
            {
                { "ID_Nucleo", n.IdNucleo },
                { "Nome", n.Nome },
                { "TotalRequisicoes", n.TotalRequisicoes }
            }).ToList();

            return result;
        }


        public async Task<bool> AddNewLeitorAsync(string nome, string email, byte[] password)
        {
            var novoLeitor = new User
            {
                Nome = nome,
                Role = "User",
                Email = email,
                Password = password, // Agora recebe diretamente como byte[]
                Isactive = true
            };

            await _context.Users.AddAsync(novoLeitor);
            await _context.SaveChangesAsync();

            return true;
        }

        // Método auxiliar para converter a senha em varbinary (simula a stored procedure)
        private byte[] ConvertPassword(string password)
        {
            return System.Text.Encoding.UTF8.GetBytes(password);
        }

        public async Task<List<Dictionary<string, object>>> GetRequisicoesAsync(DateOnly? dataInicio, DateOnly? dataFim, int? idNucleo)
        {
            return await _context.Requisicaos
                .Where(r => (!dataInicio.HasValue || r.DataReq >= dataInicio.Value) &&
                            (!dataFim.HasValue || r.DataReq <= dataFim.Value) &&
                            (!idNucleo.HasValue || r.IdNucleo == idNucleo))
                .Join(_context.Nucleos, r => r.IdNucleo, n => n.IdNucleo, (r, n) => new { r, n })
                .Join(_context.Obras, rn => rn.r.IdObra, o => o.IdObra, (rn, o) => new { rn, o })
                .Join(_context.Users, rno => rno.rn.r.IdUser, u => u.IdUser, (rno, u) => new
                {
                    Nucleo = rno.rn.n.Nome,  // Nome do Núcleo
                    Obra = rno.o.Titulo,  // Título da Obra
                    Leitor = u.Nome,  // Nome do Leitor
                    DataRequisicao = rno.rn.r.DataReq,
                    DataDevolucao = rno.rn.r.DataDev,
                    Status = rno.rn.r.Status == "Ativo" ? "Ativa" : "Devolvida"
                })
                .OrderBy(r => r.Nucleo)  // Agora o nome do Núcleo está disponível
                .ThenBy(r => r.DataRequisicao)
                .Select(r => new Dictionary<string, object>
                {
            { "Nucleo", r.Nucleo },
            { "Obra", r.Obra },
            { "Leitor", r.Leitor },
            { "DataRequisicao", r.DataRequisicao },
            { "DataDevolucao", r.DataDevolucao },
            { "Status", r.Status }
                })
                .ToListAsync();
        }

        public async Task<int> UpdateExemplaresObraAsync(int idObra, int idNucleo, int exemplares)
        {
            var obraNucleo = await _context.ObraNucleos
                .FirstOrDefaultAsync(oc => oc.IdObra == idObra && oc.IdNucleo == idNucleo);

            if (obraNucleo == null)
            {
                // Log para verificar o que aconteceu se a entrada não for encontrada
                Console.WriteLine($"Erro: Não foi encontrado registro com idObra = {idObra} e idNucleo = {idNucleo}");
                return 0;
            }

            // Se a entrada for encontrada, faz a atualização
            obraNucleo.Exemplares = exemplares;

            return await _context.SaveChangesAsync();
        }


        public async Task<List<Dictionary<string, object>>> TransferirExemplaresAsync(int idObra, int idNucleoOrigem, int idNucleoDestino, int quantidade)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Verificar se há exemplares suficientes no núcleo de origem
                var exemplaresOrigem = await _context.ObraNucleos
                    .Where(on => on.IdObra == idObra && on.IdNucleo == idNucleoOrigem)
                    .Select(on => on.Exemplares)
                    .FirstOrDefaultAsync();

                if (exemplaresOrigem == null || exemplaresOrigem < quantidade)
                {
                    return new List<Dictionary<string, object>> { new() { { "Erro", "Não é possível concluir a transferência, exemplares insuficientes." } } };
                }

                // Subtrair exemplares do núcleo de origem
                var obraNucleoOrigem = await _context.ObraNucleos
                    .FirstOrDefaultAsync(on => on.IdObra == idObra && on.IdNucleo == idNucleoOrigem);

                if (obraNucleoOrigem != null)
                {
                    obraNucleoOrigem.Exemplares -= quantidade;
                }

                // Verificar se o núcleo de destino já possui exemplares da obra
                var obraNucleoDestino = await _context.ObraNucleos
                    .FirstOrDefaultAsync(on => on.IdObra == idObra && on.IdNucleo == idNucleoDestino);

                if (obraNucleoDestino == null)
                {
                    // Criar novo registro se ainda não existir
                    _context.ObraNucleos.Add(new ObraNucleo
                    {
                        IdObra = idObra,
                        IdNucleo = idNucleoDestino,
                        Exemplares = quantidade
                    });
                }
                else
                {
                    // Atualizar a quantidade existente
                    obraNucleoDestino.Exemplares += quantidade;
                }

                await _context.SaveChangesAsync();

                // Commit da transação
                await transaction.CommitAsync();

                // Retornar os exemplares finais
                var resultado = await _context.ObraNucleos
                    .Where(on => on.IdObra == idObra && (on.IdNucleo == idNucleoOrigem || on.IdNucleo == idNucleoDestino))
                    .Join(_context.Nucleos, on => on.IdNucleo, n => n.IdNucleo, (on, n) => new Dictionary<string, object>
                    {
                    { "Nucleo", n.Nome },
                    { "Exemplares", on.Exemplares }
                    })
                    .ToListAsync();

                return resultado;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new List<Dictionary<string, object>> { new() { { "Erro", $"Erro ao transferir exemplares: {ex.Message}" } } };
            }
        }

        public async Task<List<Dictionary<string, object>>> SuspendLeitoresAsync()
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Identificar os usuários que devem ser suspensos
                var usuariosParaSuspender = await _context.Requisicaos
                    .Where(r => EF.Functions.DateDiffDay(r.DataReq, r.DataDev) > 15 &&
                                r.Status == "Devolvido")
                    .GroupBy(r => r.IdUser)
                    .Where(g => g.Count() > 3)
                    .Select(g => g.Key)
                    .ToListAsync();

                if (!usuariosParaSuspender.Any())
                {
                    return new List<Dictionary<string, object>> { new() { { "Mensagem", "Nenhum usuário atende aos critérios de suspensão." } } };
                }

                // Atualizar usuários
                var usuariosSuspensos = await _context.Users
                    .Where(u => usuariosParaSuspender.Contains(u.IdUser))
                    .ToListAsync();

                foreach (var usuario in usuariosSuspensos)
                {
                    if (usuario.Isactive != false)  // Verifica se o usuário já não está suspenso
                    {
                        usuario.Isactive = false; // Suspende o usuário
                    }
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Retornar os usuários suspensos
                return usuariosSuspensos.Select(u => new Dictionary<string, object>
        {
            { "ID_User", u.IdUser },
            { "Nome", u.Nome },
            { "Email", u.Email },
            { "ISACTIVE", (u.Isactive ?? false) ? "True" : "False" } // Converte para string
        }).ToList();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new List<Dictionary<string, object>> { new() { { "Erro", $"Erro ao suspender leitores: {ex.Message}" } } };
            }
        }


        public async Task<Dictionary<string, object>> ReativarLeitorAsync(int idUser)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Verificar se o leitor está suspenso
                var usuario = await _context.Users
                    .Where(u => u.IdUser == idUser && u.Isactive == false)
                    .FirstOrDefaultAsync();

                if (usuario == null)
                {
                    return new Dictionary<string, object>
            {
                { "Erro", "O leitor não está suspenso ou não existe." }
            };
                }

                // Atualizar o estado do leitor para ativo
                usuario.Isactive = true;
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Retornar informações do leitor atualizado
                return new Dictionary<string, object>
        {
            { "ID_User", usuario.IdUser },
            { "Nome", usuario.Nome },
            { "Email", usuario.Email },
            { "ISACTIVE", (usuario.Isactive ?? false) ? "True" : "False" }
        };
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new Dictionary<string, object>
        {
            { "Erro", $"Erro ao reativar leitor: {ex.Message}" }
        };
            }
        }

        public async Task<bool> AddNewObraAsync(string titulo, string autor, string sinopse, string imageFilePath = null)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Inserir na tabela Obras
                var novaObra = new XPTO_Data.Entities.Obra
                {
                    Titulo = titulo,
                    Autor = autor,
                    Sinopse = sinopse
                };
                _context.Obras.Add(novaObra);
                await _context.SaveChangesAsync();

                // Recuperar o ID da obra inserida
                int idObra = novaObra.IdObra;

                // Se um caminho de imagem foi fornecido, carregar e inserir o conteúdo da imagem
                if (!string.IsNullOrEmpty(imageFilePath))
                {
                    if (!File.Exists(imageFilePath))  // Verifica se o arquivo existe
                    {
                        throw new Exception("O caminho do arquivo de imagem não é válido.");
                    }

                    try
                    {
                        // Carregar os dados binários da imagem
                        byte[] imageData = await File.ReadAllBytesAsync(imageFilePath);

                        // Validar se é uma imagem (opcional)
                        if (!imageFilePath.EndsWith(".jpg") && !imageFilePath.EndsWith(".png"))
                        {
                            throw new Exception("O arquivo de imagem deve ser no formato JPG ou PNG.");
                        }

                        // Inserir os dados da imagem na tabela Capas
                        var novaCapa = new Capa { CapaImagem = imageData };
                        _context.Capas.Add(novaCapa);
                        await _context.SaveChangesAsync();

                        // Recuperar o ID da capa inserida
                        int idCapa = novaCapa.IdCapa;

                        // Vincular a obra à capa
                        _context.Set<ObrasCapa>().Add(new ObrasCapa { IdObra = idObra, IdCapa = idCapa });
                        await _context.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Erro ao registrar a imagem: {ex.Message}");
                        throw; // Relançar a exceção para que a transação seja revertida
                    }
                }

                await transaction.CommitAsync();
                return true;
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<Dictionary<string, object>> AddNewRequisicaoAsync(int idUser, int idObra, int idNucleo, DateOnly dataReq)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Verificar se há exemplares disponíveis no núcleo
                var obraNucleo = await _context.ObraNucleos
                    .FirstOrDefaultAsync(on => on.IdObra == idObra && on.IdNucleo == idNucleo);

                if (obraNucleo == null || obraNucleo.Exemplares <= 0)
                {
                    throw new Exception("Não há exemplares disponíveis para esta obra neste núcleo.");
                }

                // Criar a requisição
                var novaRequisicao = new XPTO_Data.Entities.Requisicao
                {
                    IdUser = idUser,
                    IdObra = idObra,
                    IdNucleo = idNucleo,
                    DataReq = dataReq,
                    Status = "Ativo"
                };
                _context.Requisicaos.Add(novaRequisicao);

                // Atualizar os exemplares
                obraNucleo.Exemplares--;

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Mostrar detalhes da requisição
                var detalhesRequisicao = await _context.Requisicaos
                    .Where(r => r.IdUser == idUser && r.IdObra == idObra && r.IdNucleo == idNucleo && r.DataReq == dataReq)
                    .Join(_context.Users, r => r.IdUser, u => u.IdUser, (r, u) => new { r, u })
                    .Join(_context.Obras, ru => ru.r.IdObra, o => o.IdObra, (ru, o) => new { ru, o })
                    .Join(_context.Nucleos, ruo => ruo.ru.r.IdNucleo, n => n.IdNucleo, (ruo, n) => new
                    {
                        NomeUsuario = ruo.ru.u.Nome,
                        TituloObra = ruo.o.Titulo,
                        NomeNucleo = n.Nome,
                        ruo.ru.r.DataReq,
                        ruo.ru.r.Status
                    })
                    .FirstOrDefaultAsync();

                return new Dictionary<string, object>
        {
            { "NomeUsuario", detalhesRequisicao.NomeUsuario },
            { "TituloObra", detalhesRequisicao.TituloObra },
            { "NomeNucleo", detalhesRequisicao.NomeNucleo },
            { "DataReq", detalhesRequisicao.DataReq },
            { "Status", detalhesRequisicao.Status }
        };
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<Dictionary<string, object>> CancelarInscricaoAsync(int idUser)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Identificar as requisições ativas do utilizador
                var requisicoesAtivas = await _context.Requisicaos
                    .Where(r => r.IdUser == idUser && r.Status == "Ativo" && r.DataDev == null)
                    .ToListAsync();

                // Se existirem requisições ativas, processar devolução
                if (requisicoesAtivas.Any())
                {
                    // Atualizar o status das requisições para 'Devolvido' e definir a DataDev
                    foreach (var requisicao in requisicoesAtivas)
                    {
                        requisicao.Status = "Devolvido";
                        requisicao.DataDev = DateOnly.FromDateTime(DateTime.Now);

                        // Atualizar os exemplares disponíveis nos núcleos
                        var obraNucleo = await _context.ObraNucleos
                            .FirstOrDefaultAsync(on => on.IdObra == requisicao.IdObra && on.IdNucleo == requisicao.IdNucleo);
                        if (obraNucleo != null)
                        {
                            obraNucleo.Exemplares++;
                        }
                    }
                }

                // Mostrar as informações após a transação
                var nomeUser = await _context.Users
                    .Where(u => u.IdUser == idUser)
                    .Select(u => u.Nome)
                    .FirstOrDefaultAsync();

                var obrasDevolvidas = await _context.Requisicaos
                    .Where(r => r.IdUser == idUser && r.Status == "Devolvido")
                    .Join(_context.Obras, r => r.IdObra, o => o.IdObra, (r, o) => o.Titulo)
                    .ToListAsync();

                // Mover o utilizador e requisições para o histórico
                var historico = await _context.Users
                    .Where(u => u.IdUser == idUser)
                    .Select(u => new Historico
                    {
                        IdUser = u.IdUser,
                        Nome = u.Nome,
                        Email = u.Email,
                        TotalRequisicoes = _context.Requisicaos.Count(r => r.IdUser == u.IdUser),
                        DataEliminacao = DateOnly.FromDateTime(DateTime.Now)
                    })
                    .FirstOrDefaultAsync();

                if (historico != null)
                {
                    _context.Historicos.Add(historico);
                }

                // Remover as requisições do utilizador
                _context.Requisicaos.RemoveRange(_context.Requisicaos.Where(r => r.IdUser == idUser));

                // Remover o utilizador da tabela Users
                var user = await _context.Users.FindAsync(idUser);
                if (user != null)
                {
                    _context.Users.Remove(user);
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return new Dictionary<string, object>
        {
            { "User_Eliminado", nomeUser },
            { "Obras_Devolvidas", obrasDevolvidas }
        };
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task AtualizarEstadoRequisicaoAsync(int idRequisicao, string novoEstado)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var requisicao = await _context.Requisicaos.FindAsync(idRequisicao);
                if (requisicao == null)
                {
                    throw new Exception("Requisição não encontrada.");
                }

                requisicao.Status = novoEstado;
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }
        public async Task AdicionarObraNucleoAsync(int idObra, int idNucleo, int exemplares)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var obraNucleo = new ObraNucleo
                {
                    IdObra = idObra,
                    IdNucleo = idNucleo,
                    Exemplares = exemplares
                };

                _context.ObraNucleos.Add(obraNucleo);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }
    }
}