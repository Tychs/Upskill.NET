﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace XPTO_Data.Entities;

public partial class Nucleo
{
    public int IdNucleo { get; set; }

    public string Nome { get; set; } = null!;

    public virtual ICollection<ObraNucleo> ObraNucleos { get; set; } = new List<ObraNucleo>();

    public virtual ICollection<Requisicao> Requisicaos { get; set; } = new List<Requisicao>();
}
