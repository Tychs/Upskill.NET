﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace XPTO_Data.Entities;

public partial class XPTOContext : DbContext
{
    public XPTOContext()
    {
    }

    public XPTOContext(DbContextOptions<XPTOContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Capa> Capas { get; set; }

    public virtual DbSet<Historico> Historicos { get; set; }

    public virtual DbSet<Nucleo> Nucleos { get; set; }

    public virtual DbSet<Obra> Obras { get; set; }

    public virtual DbSet<ObraNucleo> ObraNucleos { get; set; }

    public virtual DbSet<Requisicao> Requisicaos { get; set; }

    public virtual DbSet<Tema> Temas { get; set; }

    public virtual DbSet<User> Users { get; set; }
    public object ObrasCapas { get; internal set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=localhost;Database=XPTO_Final;Trusted_Connection=True;TrustServerCertificate=True");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Capa>(entity =>
        {
            entity.HasKey(e => e.IdCapa).HasName("PK__Capas__72E94C6D99C407E5");

            entity.Property(e => e.IdCapa).HasColumnName("ID_Capa");
            entity.Property(e => e.Capa1).HasColumnName("Capa");
        });

        modelBuilder.Entity<Historico>(entity =>
        {
            entity.HasKey(e => e.IdHistorico).HasName("PK_Arquivo_Morto");

            entity.ToTable("Historico");

            entity.Property(e => e.IdHistorico).HasColumnName("ID_Historico");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.IdUser).HasColumnName("ID_User");
            entity.Property(e => e.Nome).HasMaxLength(150);
        });

        modelBuilder.Entity<Nucleo>(entity =>
        {
            entity.HasKey(e => e.IdNucleo).HasName("PK__Nucleos__95E6C716D6BA6675");

            entity.Property(e => e.IdNucleo).HasColumnName("ID_Nucleo");
            entity.Property(e => e.Nome).HasMaxLength(100);
        });

        modelBuilder.Entity<Obra>(entity =>
        {
            entity.HasKey(e => e.IdObra).HasName("PK__Obras__46EE62C0F21BCF2F");

            entity.Property(e => e.IdObra).HasColumnName("ID_Obra");
            entity.Property(e => e.Autor).HasMaxLength(100);
            entity.Property(e => e.Sinopse).HasMaxLength(500);
            entity.Property(e => e.Titulo).HasMaxLength(100);

            entity.HasMany(d => d.IdCapas).WithMany(p => p.IdObras)
                .UsingEntity<Dictionary<string, object>>(
                    "ObrasCapa",
                    r => r.HasOne<Capa>().WithMany()
                        .HasForeignKey("IdCapa")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_Capa"),
                    l => l.HasOne<Obra>().WithMany()
                        .HasForeignKey("IdObra")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_Obra"),
                    j =>
                    {
                        j.HasKey("IdObra", "IdCapa").HasName("PK__Obras_Ca__01CF21213DF9D52C");
                        j.ToTable("Obras_Capas");
                        j.IndexerProperty<int>("IdObra").HasColumnName("ID_Obra");
                        j.IndexerProperty<int>("IdCapa").HasColumnName("ID_Capa");
                    });
        });

        modelBuilder.Entity<ObraNucleo>(entity =>
        {
            entity.HasKey(e => new { e.IdObra, e.IdNucleo }).HasName("PK__ObraNucl__3FB00EB162E8FD33");

            entity.ToTable("ObraNucleo");

            entity.Property(e => e.IdObra).HasColumnName("ID_Obra");
            entity.Property(e => e.IdNucleo).HasColumnName("ID_Nucleo");
            entity.Property(e => e.Exemplares).HasDefaultValue(1);

            entity.HasOne(d => d.IdNucleoNavigation).WithMany(p => p.ObraNucleos)
                .HasForeignKey(d => d.IdNucleo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ObraNucleo_Nucleo");

            entity.HasOne(d => d.IdObraNavigation).WithMany(p => p.ObraNucleos)
                .HasForeignKey(d => d.IdObra)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ObraNucleo_Obra");
        });

        modelBuilder.Entity<Requisicao>(entity =>
        {
            entity.HasKey(e => e.IdRequisicao).HasName("PK__Requisic__7B7D23BB5E356CDB");

            entity.ToTable("Requisicao");

            entity.Property(e => e.IdRequisicao).HasColumnName("ID_Requisicao");
            entity.Property(e => e.IdNucleo).HasColumnName("ID_Nucleo");
            entity.Property(e => e.IdObra).HasColumnName("ID_Obra");
            entity.Property(e => e.IdUser).HasColumnName("ID_User");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasDefaultValue("Ativo");

            entity.HasOne(d => d.IdNucleoNavigation).WithMany(p => p.Requisicaos)
                .HasForeignKey(d => d.IdNucleo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisicao_Nucleo");

            entity.HasOne(d => d.IdObraNavigation).WithMany(p => p.Requisicaos)
                .HasForeignKey(d => d.IdObra)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisicao_Obra");

            entity.HasOne(d => d.IdUserNavigation).WithMany(p => p.Requisicaos)
                .HasForeignKey(d => d.IdUser)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisicao_Leitor");
        });

        modelBuilder.Entity<Tema>(entity =>
        {
            entity.HasKey(e => e.IdTema).HasName("PK__Temas__D659FE8F5712956F");

            entity.Property(e => e.IdTema).HasColumnName("ID_Tema");
            entity.Property(e => e.NomeTema).HasMaxLength(100);

            entity.HasMany(d => d.IdObras).WithMany(p => p.IdTemas)
                .UsingEntity<Dictionary<string, object>>(
                    "TemaObra",
                    r => r.HasOne<Obra>().WithMany()
                        .HasForeignKey("IdObra")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_TemaObra_Obra"),
                    l => l.HasOne<Tema>().WithMany()
                        .HasForeignKey("IdTema")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_TemaObra_Tema"),
                    j =>
                    {
                        j.HasKey("IdTema", "IdObra").HasName("PK__TemaObra__C23718A319CF4D03");
                        j.ToTable("TemaObra");
                        j.IndexerProperty<int>("IdTema").HasColumnName("ID_Tema");
                        j.IndexerProperty<int>("IdObra").HasColumnName("ID_Obra");
                    });
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.IdUser).HasName("PK__Leitores__8DB91E1493E992AC");

            entity.HasIndex(e => e.Email, "UQ__Leitores__A9D10534F786CFF4").IsUnique();

            entity.Property(e => e.IdUser).HasColumnName("ID_User");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Isactive)
                .HasDefaultValue(true)
                .HasColumnName("ISACTIVE");
            entity.Property(e => e.Nome).HasMaxLength(150);
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.Role).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}