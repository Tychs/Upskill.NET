﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace XPTO_Data.Entities;


[PrimaryKey("IdTema", "IdObra")]
[Table("TemaObra")]
public partial class TemaObra
{
    [Key]
    [Column("ID_Tema")]
    public int IdTema { get; set; }

    [Key]
    [Column("ID_Obra")]
    public int IdObra { get; set; }
}
