﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace XPTO_Data.Entities;

public partial class Capa
{
    public int IdCapa { get; set; }

    public byte[]? Capa1 { get; set; }

    public virtual ICollection<Obra> IdObras { get; set; } = new List<Obra>();
    public byte[] CapaImagem { get; internal set; }
}
