﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace XPTO_Data.Entities;


[PrimaryKey("IdObra", "IdCapa")]
[Table("Obras_Capas")]
public partial class ObrasCapa
{
    [Key]
    [Column("ID_Obra")]
    public int IdObra { get; set; }

    [Key]
    [Column("ID_Capa")]
    public int IdCapa { get; set; }
}
