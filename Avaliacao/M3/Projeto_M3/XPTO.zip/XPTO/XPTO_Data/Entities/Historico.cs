﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace XPTO_Data.Entities;

public partial class Historico
{
    public int IdHistorico { get; set; }

    public int IdUser { get; set; }

    public string Nome { get; set; } = null!;

    public string Email { get; set; } = null!;

    public int TotalRequisicoes { get; set; }

    public DateOnly? DataEliminacao { get; set; }
}
