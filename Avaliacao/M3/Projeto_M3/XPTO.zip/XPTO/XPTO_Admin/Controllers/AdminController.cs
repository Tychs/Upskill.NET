﻿using Microsoft.AspNetCore.Mvc;

namespace XPTO_Admin.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }
    }
}
