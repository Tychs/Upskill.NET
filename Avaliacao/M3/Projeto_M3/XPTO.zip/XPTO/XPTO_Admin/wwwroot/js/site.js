﻿// ADD NEW User
// Chamar esta função para mostrar o formulário
function mostrarFormulario() {
    document.getElementById('userAddForm').classList.add('show-form');
}

// Capturar o evento de envio do formulário apenas uma vez
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById('userAddForm');

    if (form) {
        form.addEventListener('submit', adicionarUsuario);
    } else {
        console.error("Erro: Formulário de adição de usuário não encontrado.");
    }
});

// Função para adicionar o usuário
async function adicionarUsuario(event) {
    event.preventDefault(); // Evita o envio do formulário e recarregamento da página

    // Obtém os dados do formulário
    const userData = {
        nome: document.getElementById('nomeAdd').value,
        email: document.getElementById('emailAdd').value,
        password: btoa(document.getElementById('passwordAdd').value),  // Codifica a senha em Base64
    };

    try {
        // Envia os dados para a API para adicionar o novo usuário
        const response = await fetch("http://localhost:5026/api/admin/add-leitor", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(userData), // Aqui enviamos apenas os dados essenciais
        });

        // Verifica se a resposta foi bem-sucedida
        if (response.ok) {
            const data = await response.json();  // Aqui você obtém a resposta JSON
            alert(data);  // Exibe a resposta direta da API
            limparCampos();  // Limpa os campos do formulário
        }
    } catch (error) {
        console.error('Erro ao comunicar com o servidor:', error);
        alert('Erro ao comunicar com o servidor: ' + error.message);
    }
}

// Função para limpar os campos do formulário
function limparCampos() {
    document.getElementById('nomeAdd').value = '';
    document.getElementById('emailAdd').value = '';
    document.getElementById('passwordAdd').value = '';
}

// Função para editar usuário
async function editarUsuario(id) {
    try {
        const response = await fetch(`http://localhost:5026/api/admin/usuarios/${id}`);

        if (!response.ok) {
            throw new Error('Usuário não encontrado ou erro ao buscar dados.');
        }

        const user = await response.json();

        console.log("Usuário carregado:", user);

        // Atualiza os campos do formulário de edição
        document.getElementById('editNome').value = user.nome;
        document.getElementById('editEmail').value = user.email;
        document.getElementById('editIsactive').checked = user.isactive;

        // Torna o formulário visível
        document.getElementById('editUserForm').style.display = 'block';

        // Atualiza a função do botão de salvar para garantir que salva o usuário correto
        document.getElementById('userEditForm').onsubmit = async function (event) {
            event.preventDefault(); // Evita recarregar a página

            const updatedUser = {
                idUser: user.idUser,
                nome: document.getElementById('editNome').value,
                email: document.getElementById('editEmail').value,
                isactive: document.getElementById('editIsactive').checked,
            };

            try {
                const updateResponse = await fetch(`http://localhost:5026/api/admin/usuarios/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(updatedUser),
                });

                if (updateResponse.ok) {
                    alert('Usuário atualizado com sucesso!');
                    location.reload();
                } else {
                    alert('Erro ao atualizar o usuário.');
                }
            } catch (error) {
                alert('Erro ao salvar as alterações.');
                console.error(error);
            }
        };
    } catch (error) {
        console.error('Erro:', error);
        alert(error.message);
    }
}

// Função para fechar o formulário de edição
function closeEditForm() {
    document.getElementById('editUserForm').style.display = 'none';
}


// Função para excluir usuário
async function eliminarUsuario(id) {
    try {
        const response = await fetch(`http://localhost:5026/api/admin/usuarios/${id}`, { method: 'DELETE' });

        if (!response.ok) {
            throw new Error('Usuário não encontrado ou erro ao excluir.');
        }

        alert('Usuário excluído com sucesso!');
        location.reload();
    } catch (error) {
        console.error('Erro:', error);
        alert(error.message);
    }
}



function filtrarUsuarios() {
    const input = document.getElementById("searchInput").value.toLowerCase();
    const rows = document.querySelectorAll("#userList tr");

    rows.forEach(row => {
        const nome = row.cells[1].innerText.toLowerCase();
        const email = row.cells[2].innerText.toLowerCase();

        if (nome.includes(input) || email.includes(input)) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
}

let ordemAscendente = true;

function ordenarUsuarios(propriedade) {
    const userList = document.getElementById("userList");
    const rows = Array.from(userList.getElementsByTagName("tr"));

    rows.sort((a, b) => {
        let valA = a.cells[0].innerText;
        let valB = b.cells[0].innerText;

        if (propriedade === "nome") {
            valA = a.cells[1].innerText.toLowerCase();
            valB = b.cells[1].innerText.toLowerCase();
        } else {
            valA = parseInt(valA);
            valB = parseInt(valB);
        }

        return ordemAscendente ? (valA > valB ? 1 : -1) : (valA < valB ? 1 : -1);
    });

    ordemAscendente = !ordemAscendente;

    userList.innerHTML = "";
    rows.forEach(row => userList.appendChild(row));
}
document.addEventListener("DOMContentLoaded", () => {
    console.log("🚀 site.js loaded!");

    // SIDEBAR NAVIGATION
    const links = document.querySelectorAll(".sidebar a");
    const sections = document.querySelectorAll(".section");

    links.forEach(link => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            const sectionId = link.getAttribute("data-section");

            // Hide all sections
            sections.forEach(sec => sec.classList.remove("active"));

            // Show the targeted section
            const targetSection = document.getElementById(sectionId);
            if (targetSection) {
                targetSection.classList.add("active");
            }
        });
    });

    // HELPER FUNCTION: Show alert messages
    function showMessage(message, type = "info") {
        const responseMsg = document.getElementById("responseMessage");
        if (!responseMsg) return;

        // Update text and styling
        responseMsg.innerText = message;
        responseMsg.className = `alert alert-${type} mt-3`;
        responseMsg.style.display = "block";

        // Hide automatically after 5 seconds
        setTimeout(() => {
            responseMsg.style.display = "none";
        }, 5000);
    }

    // HELPER FUNCTION: Fetch JSON
    async function fetchJson(url, options = {}) {
        try {
            const response = await fetch(url, options);

            // Check if the response is not OK (status code not in the 2xx range)
            if (!response.ok) {
                const errorText = await response.text();  // Get the error response as text
                const errorMessage = errorText ? errorText : `HTTP Error: ${response.status}`;
                throw new Error(errorMessage); // Throw error with the message from the response
            }

            // If the response body is not empty, try to parse it as JSON
            const text = await response.text();
            try {
                return text ? JSON.parse(text) : {};  // If there is content, parse it as JSON
            } catch (jsonError) {
                // If parsing fails, just return the raw text content (in case it's not JSON)
                console.warn("Response is not valid JSON, returning raw text", jsonError);
                return text;
            }

        } catch (error) {
            console.error("❌ Request Error:", error);
            showMessage(`Erro: ${error.message}`, "danger");
            throw error;  // Re-throw the error for further handling
        }
    }

    // GET ALL USERS
    const listarUsuariosLink = document.querySelector('[data-section="getAllUsers"]');
    if (listarUsuariosLink) {
        listarUsuariosLink.addEventListener("click", async (e) => {
            e.preventDefault();

            try {
                // Fetch users da API
                const result = await fetch("http://localhost:5026/api/admin/usuarios", {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                });

                const users = await result.json();
                console.log("🔹 Dados recebidos da API:", JSON.stringify(users, null, 2));

                const userList = document.getElementById("userList");
                userList.innerHTML = ""; // Limpar conteúdo anterior

                if (users && users.length > 0) {
                    users.forEach(user => {
                        const id = user.idUser ?? "Sem ID";
                        const nome = user.nome ?? "Sem Nome";
                        const email = user.email ?? "Sem Email";
                        const isActive = (user.isactive === true || user.isactive === "true" || user.isactive === 1 || user.isactive === "1") ? "✅ Sim" : "❌ Não";

                        const row = document.createElement("tr");
                        row.innerHTML = `
                <td>${id}</td>
                <td>${nome}</td>
                <td>${email}</td>
                <td>${isActive}</td>
                <td>
                    <button onclick="editarUsuario(${id})">✏️ Editar</button>
                    <button onclick="eliminarUsuario(${id})">🗑️ Excluir</button>
                </td>
            `;
                        userList.appendChild(row);
                    });
                } else {
                    userList.innerHTML = "<tr><td colspan='5'>Nenhum usuário encontrado.</td></tr>";
                }
            } catch (error) {
                console.error("❌ Error:", error);
                document.getElementById("userList").innerHTML = "<tr><td colspan='5'>Erro ao buscar usuários.</td></tr>";
            }
        });
    }

    // REQUISIÇÕES ATIVAS
    document.getElementById("getStatusRequisicoesBtn").addEventListener("click", async () => {
        // Valores selecionados nos filtros
        let idNucleo = document.getElementById("nucleoSelect").value;
        let urgencyFilter = document.getElementById("statusSelect").value;

        // Se o valor de idNucleo for vazio, definimos como null
        idNucleo = idNucleo ? parseInt(idNucleo, 10) : null;

        console.log(`🔍 Núcleo selecionado: ${idNucleo}`);
        console.log(`🔍 Filtro de urgência selecionado: ${urgencyFilter}`);

        try {
            let url = "http://localhost:5026/api/admin/estado-requisicoes";

            // Adiciona parâmetro de idNucleo
            if (idNucleo !== null) {
                url += `?idNucleo=${idNucleo}`;
            }

            // Adiciona parâmetro de urgencyFilter
            if (urgencyFilter) {
                url += (url.includes('?') ? '&' : '?') + `urgencyFilter=${encodeURIComponent(urgencyFilter)}`;
            }

            console.log("🔗 URL da requisição:", url);

            // Faz a requisição
            const result = await fetch(url, {
                method: "GET",
                headers: { "Content-Type": "application/json" },
            }).then(response => response.json());

            console.log("📦 Dados recebidos:", result);

            // Preenche a tabela com as requisições
            const statusRequisicoesBody = document.getElementById("statusRequisicoesBody");

            // Monta as linhas da tabela dinamicamente
            statusRequisicoesBody.innerHTML = result.map(r => {
                // Adiciona classe CSS baseada no status para destacar visualmente
                let statusClass = '';
                if (r.Status === 'ATRASO') {
                    statusClass = 'text-danger fw-bold';
                } else if (r.Status === 'Devolução URGENTE') {
                    statusClass = 'text-warning fw-bold';
                }

                return `
        <tr>
            <td>${r.Titulo}</td>
            <td>${r.Leitor}</td>
            <td class="${statusClass}">${r.Status}</td>
            <td>${r.Nucleo}</td>
            <td>${r.DataReq || 'Data não disponível'}</td>
            <td>${r.DataLimiteDevolucao || 'Data não disponível'}</td>
        </tr>
    `;
            }).join("");

            // Se não houver resultados, exibe uma mensagem
            if (result.length === 0) {
                statusRequisicoesBody.innerHTML = `
        <tr>
            <td colspan="6" class="text-center">Nenhuma requisição encontrada com os filtros selecionados.</td>
        </tr>
    `;
            }
        } catch (error) {
            console.error("❌ Erro ao buscar status das requisições:", error);
            // Exibe mensagem de erro na tabela
            document.getElementById("statusRequisicoesBody").innerHTML = `
        <tr>
            <td colspan="6" class="text-center text-danger">Erro ao buscar requisições. Tente novamente.</td>
        </tr>
    `;
        }
    });

    // HISTÓRICO DE REQUISIÇÕES
    document.getElementById("getHistoricoRequisicoesBtn").addEventListener("click", async () => {
        // Valor do filtro do Núcleo
        let idNucleo = document.getElementById("nucleoHistoricoSelect").value;
        idNucleo = idNucleo ? parseInt(idNucleo, 10) : null;

        // Valor do filtro de Data de Requisição
        let dataRequisicao = document.getElementById("dataHistoricoRequisicao").value;
        dataRequisicao = dataRequisicao || null;

        console.log(`🔍 Filtro de Núcleo histórico: ${idNucleo}, Filtro de Data Requisição: ${dataRequisicao}`);

        try {
            let url = "http://localhost:5026/api/admin/historico-requisicoes";

            // Adiciona parâmetros de idNucleo e dataRequisicao, se fornecidos
            let params = [];

            if (idNucleo !== null) {
                params.push(`idNucleo=${idNucleo}`);
            }

            if (dataRequisicao) {
                params.push(`dataRequisicao=${dataRequisicao}`);
            }

            // Se houver parâmetros, adiciona ao URL
            if (params.length > 0) {
                url += `?${params.join("&")}`;
            }

            console.log("🔗 URL da requisição histórico:", url);

            // Faz a requisição para o endpoint do histórico
            const result = await fetch(url, {
                method: "GET",
                headers: { "Content-Type": "application/json" },
            }).then(response => response.json());

            console.log("📦 Dados históricos recebidos:", result);

            // Preenche a tabela de histórico com as requisições
            const tbody = document.getElementById("historicoRequisicoesBody");
            tbody.innerHTML = result.map(r => {
                return `
            <tr>
                <td>${r.Titulo}</td>
                <td>${r.Leitor}</td>
                <td>${r.Nucleo}</td>
                <td>${r.DataReq || 'Data não disponível'}</td>
                <td>${r.DataDev}</td>
                <td>${r.Entrega || 'N/A'}</td>
            </tr>
        `;
            }).join("");

            // Se não houver resultados, exibe uma mensagem
            if (result.length === 0) {
                tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center">Nenhuma requisição histórica encontrada com os filtros selecionados.</td>
            </tr>
        `;
            }
        } catch (error) {
            console.error("❌ Erro ao buscar histórico das requisições:", error);
            document.getElementById("historicoRequisicoesBody").innerHTML = `
        <tr>
            <td colspan="6" class="text-center text-danger">Erro ao buscar histórico das requisições. Tente novamente.</td>
        </tr>
    `;
        }
    });

    // GET NÚCLEOS POR REQUISIÇÃO
    const getNucleosPorRequisicaoBtn = document.getElementById("getNucleosPorRequisicaoBtn");
    if (getNucleosPorRequisicaoBtn) {
        getNucleosPorRequisicaoBtn.addEventListener("click", async () => {
            const dataInicio = document.getElementById("dataInicioNucleos").value;
            const dataFim = document.getElementById("dataFimNucleos").value;

            // Construir a query string corretamente
            let url = "http://localhost:5026/api/admin/nucleos-por-requisicao";
            let params = [];

            // Adicionar os parâmetros à URL apenas se as datas não estiverem vazias
            if (dataInicio) {
                params.push(`dataInicio=${dataInicio}`);
            }
            if (dataFim) {
                params.push(`dataFim=${dataFim}`);
            }

            // Se existirem parâmetros, adicionar na URL
            if (params.length > 0) {
                url += "?" + params.join("&");
            }

            try {
                const result = await fetchJson(url, {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                });

                const nucleosPorRequisicaoTableBody = document.getElementById("nucleosPorRequisicaoTableBody");
                nucleosPorRequisicaoTableBody.innerHTML = result.map(n =>
                    `<tr>
                    <td>${n.Nome}</td>
                    <td>${n.TotalRequisicoes}</td>
                </tr>`
                ).join(""); // Converte os dados para linhas de tabela
            } catch (error) {
                console.error("❌ Request Error:", error);
            }
        });
    }

    // GET REQUISIÇÕES
    const getRequisicoesBtn = document.getElementById("getRequisicoesBtn");
    if (getRequisicoesBtn) {
        getRequisicoesBtn.addEventListener("click", async () => {
            const dataInicio = document.getElementById("dataInicioRequisicoes").value;
            const dataFim = document.getElementById("dataFimRequisicoes").value;
            const idNucleo = document.getElementById("idNucleoRequisicoes").value.trim();

            try {
                const result = await fetchJson(`http://localhost:5026/api/admin/requisicoes?dataInicio=${dataInicio}&dataFim=${dataFim}&idNucleo=${idNucleo}`, {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                });

                const requisicoesList = document.getElementById("requisicoesList");
                requisicoesList.innerHTML = result.map(r => `<li>${r.Nucleo} - ${r.Obra} - ${r.Leitor} - ${r.Status}</li>`).join("");
            } catch (error) {
                console.error("❌ Error:", error);
            }
        });
    }

    // UPDATE EXEMPLARES OBRA
    const updateExemplaresObraForm = document.getElementById("updateExemplaresObraForm");

    if (updateExemplaresObraForm) {
        updateExemplaresObraForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const idObra = document.getElementById("idObraExemplares").value.trim();
            const idNucleo = document.getElementById("idNucleoExemplares").value.trim();
            const quantidade = document.getElementById("exemplaresExemplares").value.trim();

            // Verificar os valores antes de enviar
            console.log(`idObra: ${idObra}, idNucleo: ${idNucleo}, quantidade: ${quantidade}`);

            try {
                const url = `http://localhost:5026/api/obra/atualizar-exemplares?idObra=${idObra}&idNucleo=${idNucleo}&exemplares=${quantidade}`;
                console.log("URL de Requisição: ", url);  // Log da URL

                const result = await fetch(url, {
                    method: "PUT",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json"
                    }
                });

                if (!result.ok) {
                    const errorData = await result.json();
                    throw new Error(errorData.message || "Erro desconhecido");
                }

                const data = await result.json();
                showMessage(data.message, "success");

            } catch (error) {
                console.error("❌ Erro:", error);
                showMessage(error.message, "danger");
            }
        });
    }



    // REATIVAR LEITOR
    const reativarForm = document.getElementById("reativarLeitorForm");
    if (reativarForm) {
        reativarForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const idUser = document.getElementById("idLeitorReativar").value.trim();
            if (!idUser) {
                showMessage("Por favor insira o ID do leitor.", "warning");
                return;
            }

            try {
                const result = await fetchJson("http://localhost:5026/api/leitor/reativar", {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ idUser })
                });

                if (result.Erro) {
                    showMessage(result.Erro, "danger");
                } else {
                    showMessage("Leitor reativado com sucesso!", "success");
                }
            } catch (error) {

            }
        });
    }

    // SUSPENDER LEITORES
    const suspenderBtn = document.getElementById("suspenderLeitoresBtn");
    if (suspenderBtn) {
        suspenderBtn.addEventListener("click", async () => {
            try {
                const response = await fetch("http://localhost:5026/api/admin/suspender-leitores", {
                    method: "PUT"
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    showMessage(`Erro: ${errorData.message}`, "danger");
                } else {
                    showMessage("Leitores suspensos com sucesso!", "success");
                }
            } catch (error) {
                console.error("❌ Suspender Error:", error);
                showMessage(`Erro: ${error.message}`, "danger");
            }
        });
    }

    // TRANSFERIR EXEMPLARES
    const transferirForm = document.getElementById("transferirExemplaresForm");
    if (transferirForm) {
        transferirForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const idObra = document.getElementById("idObraTransferir").value.trim();
            const idNucleoOrigem = document.getElementById("idNucleoOrigem").value.trim();
            const idNucleoDestino = document.getElementById("idNucleoDestino").value.trim();
            const quantidade = document.getElementById("quantidadeTransferir").value.trim();

            // Basic validation
            if (!idObra || !idNucleoOrigem || !idNucleoDestino || !quantidade) {
                showMessage("Por favor, preencha todos os campos.", "warning");
                return;
            }

            try {
                const queryParams = new URLSearchParams({
                    idObra,
                    idNucleoOrigem,
                    idNucleoDestino,
                    quantidade
                }).toString();

                const result = await fetchJson(`http://localhost:5026/api/obra/transferir-exemplares?${queryParams}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" }
                });

                showMessage("Transferência concluída!", "success");
            } catch (error) {

            }
        });
    }

    // Mostrar formulário de adicionar obra
    function mostrarFormularioObra() {
        document.getElementById('addObraForm').style.display = 'block';
    }

    // Adicionar nova obra
    document.addEventListener("DOMContentLoaded", () => {
        const obraForm = document.getElementById('obraForm');
        if (obraForm) {
            obraForm.addEventListener('submit', adicionarObra);
        }
    });

    async function adicionarObra(event) {
        event.preventDefault();

        const formData = new FormData(document.getElementById('obraForm'));

        try {
            const response = await fetch("http://localhost:5026/api/obras/adicionar", {
                method: "POST",
                body: formData,
            });

            if (response.ok) {
                alert("Obra adicionada com sucesso!");
                document.getElementById('addObraForm').style.display = 'none';
            } else {
                const errorData = await response.json();
                alert(`Erro: ${errorData.message || "Erro ao adicionar obra."}`);
            }
        } catch (error) {
            console.error("Erro ao adicionar obra:", error);
            alert("Erro ao adicionar obra. Tente novamente.");
        }
    }

    // Adicionar nova requisição
    document.addEventListener("DOMContentLoaded", () => {
        const requisicaoForm = document.getElementById('requisicaoForm');
        if (requisicaoForm) {
            requisicaoForm.addEventListener('submit', adicionarRequisicao);
        }
    });

    async function adicionarRequisicao(event) {
        event.preventDefault();

        const requisicaoData = {
            idUser: document.getElementById('idUser').value,
            idObra: document.getElementById('idObra').value,
            idNucleo: document.getElementById('idNucleo').value,
            dataReq: document.getElementById('dataReq').value,
        };

        try {
            const response = await fetch("http://localhost:5026/api/requisicoes/adicionar", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(requisicaoData),
            });

            if (response.ok) {
                alert("Requisição adicionada com sucesso!");
                document.getElementById('addRequisicaoSection').style.display = 'none'; //Ocultar o form após adicionar
            } else {
                const errorData = await response.json();
                alert(`Erro: ${errorData.message || "Erro ao adicionar requisição."}`);
            }
        } catch (error) {
            console.error("Erro ao adicionar requisição:", error);
            alert("Erro ao adicionar requisição. Tente novamente.");
        }
    }

    async function cancelarInscricao(idUser) {
        try {
            const response = await fetch(`http://localhost:5026/api/usuarios/${idUser}/cancelar-inscricao`, {
                method: "DELETE",
            });

            if (response.ok) {
                alert("Inscrição cancelada com sucesso!");
            } else {
                const errorData = await response.json();
                alert(`Erro: ${errorData.message || "Erro ao cancelar inscrição."}`);
            }
        } catch (error) {
            console.error("Erro ao cancelar inscrição:", error);
            alert("Erro ao cancelar inscrição. Tente novamente.");
        }
    }
    async function atualizarEstadoRequisicao(idRequisicao, novoEstado) {
        try {
            const response = await fetch(`http://localhost:5026/api/requisicoes/${idRequisicao}/atualizar-estado?novoEstado=${novoEstado}`, {
                method: "PUT",
            });

            if (response.ok) {
                alert("Estado da requisição atualizado com sucesso!");
            } else {
                const errorData = await response.json();
                alert(`Erro: ${errorData.message || "Erro ao atualizar estado."}`);
            }
        } catch (error) {
            console.error("Erro ao atualizar estado:", error);
            alert("Erro ao atualizar estado. Tente novamente.");
        }
    }
    // Adicionar obra núcleo
    document.addEventListener("DOMContentLoaded", () => {
        const obraNucleoForm = document.getElementById('obraNucleoForm');
        if (obraNucleoForm) {
            obraNucleoForm.addEventListener('submit', adicionarObraNucleo);
        }
    });

    async function adicionarObraNucleo(event) {
        event.preventDefault();

        const obraNucleoData = {
            idObra: document.getElementById('idObraNucleo').value,
            idNucleo: document.getElementById('idNucleoNucleo').value,
            exemplares: document.getElementById('exemplaresNucleo').value,
        };

        try {
            const response = await fetch("http://localhost:5026/api/obras-nucleos/adicionar", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(obraNucleoData),
            });

            if (response.ok) {
                alert("Obra adicionada ao núcleo com sucesso!");
                document.getElementById('addObraNucleoSection').style.display = 'none'; //Ocultar o form após adicionar
            } else {
                const errorData = await response.json();
                alert(`Erro: ${errorData.message || "Erro ao adicionar obra ao núcleo."}`);
            }
        } catch (error) {
            console.error("Erro ao adicionar obra ao núcleo:", error);
            alert("Erro ao adicionar obra ao núcleo. Tente novamente.");
        }
    }
    function preencherTabelaUsuarios(usuarios) {
        const userList = document.getElementById('userList');
        userList.innerHTML = ''; // Limpa a tabela

        usuarios.forEach(usuario => {
            const row = userList.insertRow();
            row.innerHTML = `
                <td>${usuario.idUser}</td>
                <td>${usuario.nome}</td>
                <td>${usuario.email}</td>
                <td>${usuario.isactive ? 'Sim' : 'Não'}</td>
                <td>
                    <button onclick="editarUsuario(${usuario.idUser})">Editar</button>
                    <button onclick="excluirUsuario(${usuario.idUser})">Excluir</button>
                    <button class="cancelar-inscricao-btn" data-id="${usuario.idUser}">Cancelar Inscrição</button>
                </td>
            `;
        });
        //adicionar event listener para os novos botões criados.
        document.querySelectorAll('.cancelar-inscricao-btn').forEach(button => {
            button.addEventListener('click', function () {
                const idUser = this.dataset.id;
                cancelarInscricao(idUser);
            });
        });
    }

    function cancelarInscricao(idUser) {
        // Implementa a lógica para cancelar a inscrição do usuário com o ID especificado
        console.log(`Cancelar inscrição do usuário ${idUser}`);
    }


    function preencherTabelaRequisicoes(requisicoes) {
        const statusRequisicoesBody = document.getElementById('statusRequisicoesBody');
        statusRequisicoesBody.innerHTML = ''; // Limpa a tabela

        requisicoes.forEach(requisicao => {
            const row = statusRequisicoesBody.insertRow();
            row.innerHTML = `
                <td>${requisicao.titulo}</td>
                <td>${requisicao.leitor}</td>
                <td>${requisicao.status}</td>
                <td>${requisicao.nucleo}</td>
                <td>${requisicao.dataRequisicao}</td>
                <td>${requisicao.dataLimiteDevolucao}</td>
                <td>
                    <button class="devolver-requisicao-btn" data-id="${requisicao.idRequisicao}">Marcar como Devolvida</button>
                </td>
            `;
        });
        //adicionar event listener para os novos botões criados.
        document.querySelectorAll('.devolver-requisicao-btn').forEach(button => {
            button.addEventListener('click', function () {
                const idRequisicao = this.dataset.id;
                atualizarEstadoRequisicao(idRequisicao, 'Devolvido');
            });
        });
    }

    function atualizarEstadoRequisicao(idRequisicao, novoEstado) {
        // Implementa a lógica para atualizar o estado da requisição
        console.log(`Marcar requisição ${idRequisicao} como ${novoEstado}`);
    }
});
