using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace XPTO_User.Pages
{
    public class RequisicoesModel : PageModel
    {
        private readonly UserData _userData;

        public RequisicoesModel(UserData userData)
        {
            _userData = userData;
        }

        public List<RequisicaoModel> RequisicoesAtivas { get; set; } = new List<RequisicaoModel>();
        public List<RequisicaoModel> TodasRequisicoes { get; set; } = new List<RequisicaoModel>();

        public void OnGet()
        {
            // Obt�m o ID do usu�rio autenticado
            string userIdString = HttpContext.Session.GetString("UsuarioId");

            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
            {
                // Redireciona para login se n�o estiver autenticado
                RedirectToPage("/Login");
                return;
            }

            // Busca as requisi��es ativas e devolvidas separadamente
            var requisicoesAtivas = _userData.GetRequisicoesByUser(userId, "Ativo");
            var requisicoesDevolvidas = _userData.GetRequisicoesByUser(userId, "Devolvido");

            // Separa��o de requisicoes
            RequisicoesAtivas = requisicoesAtivas;
            TodasRequisicoes = requisicoesDevolvidas;

            Console.WriteLine($"Requisi��es ativas: {RequisicoesAtivas.Count}");
            Console.WriteLine($"Requisi��es devolvidas: {TodasRequisicoes.Count}");
        }
    }
}
