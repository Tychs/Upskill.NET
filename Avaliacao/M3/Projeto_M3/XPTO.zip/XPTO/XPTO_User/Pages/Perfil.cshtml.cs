using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;

public class ProfileModel : PageModel
{
    private readonly UserData _userData;

    public ProfileModel(UserData userData)
    {
        _userData = userData;
    }

    public UserModel User { get; set; }

    public IActionResult OnGet()
    {
        // Obter ID do usu�rio autenticado da sess�o
        string userIdString = HttpContext.Session.GetString("UsuarioId");

        if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
        {
            // Redirecionar para a p�gina de login, caso n�o tenha um usu�rio autenticado
            return RedirectToPage("/Index");
        }

        // Obter os dados do usu�rio com base no ID
        User = _userData.GetUserById(userId);

        if (User == null)
        {
            return NotFound(); // Caso o usu�rio n�o seja encontrado
        }

        return Page();
    }

}
