using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using XPTO_Data;  // Incluindo o namespace correto para UserData
using XPTO_Data.Entities;
using System.Data.SqlClient;

namespace XPTO_User.Pages
{
    public class ObrasModel : PageModel
    {
        private readonly UserData _userData;  // Usando UserData para acessar o banco de dados

        public string SearchTerm { get; set; } = string.Empty;
        public List<ObraViewModel> Obras { get; set; } = new List<ObraViewModel>();

        // Injetar UserData no construtor
        public ObrasModel(UserData userData)
        {
            _userData = userData ?? throw new ArgumentNullException(nameof(userData));
        }

        public void OnGet(string? searchTerm)
        {
            SearchTerm = searchTerm ?? string.Empty;

            // Criar a consulta SQL para buscar as obras
            var query = "SELECT * FROM Obras";

            if (!string.IsNullOrEmpty(SearchTerm))
            {
                query += " WHERE Titulo LIKE @SearchTerm OR Autor LIKE @SearchTerm";
            }

            // Usar ADO.NET para recuperar as obras
            using (var connection = _userData.GetConnection())
            {
                connection.Open();

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SearchTerm", "%" + SearchTerm + "%");

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Supondo que as obras tenham um ID_Obra, Titulo, Autor, etc.
                            int idObra = reader.GetInt32(reader.GetOrdinal("ID_Obra"));
                            string titulo = reader.GetString(reader.GetOrdinal("Titulo"));
                            string autor = reader.GetString(reader.GetOrdinal("Autor"));
                            string? sinopse = reader.IsDBNull(reader.GetOrdinal("Sinopse")) ? null : reader.GetString(reader.GetOrdinal("Sinopse"));

                            // Acessar a imagem base64 da tabela de capas (assumindo que voc� tenha uma tabela separada de "Capas")
                            byte[] capaData = _userData.GetImageByObra(idObra); // M�todo para consultar a imagem bin�ria pelo titulo

                            Obras.Add(new ObraViewModel
                            {
                                IdObra = idObra,
                                Titulo = titulo,
                                Autor = autor,
                                Sinopse = sinopse,
                                CapaBase64 = capaData != null
                                    ? $"data:image/png;base64,{Convert.ToBase64String(capaData)}"  // Converte para base64
                                    : $"/img/{titulo}.png"  // Ou utiliza o arquivo baseado no t�tulo (ex.: "1984.png")
                            });
                        }
                    }
                }
            }
        }
    }
}
