using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using XPTO_Data;
using XPTO_Data.Entities;
using System.Data.SqlClient;
using XPTO_User.Pages;

namespace XPTO_User.Pages
{
    public class ObraDetalhesModel : PageModel
    {
        private readonly UserData _userData;

        public ObraViewModel? Obra { get; set; }

        // Injetar UserData no construtor
        public ObraDetalhesModel(UserData userData)
        {
            _userData = userData ?? throw new ArgumentNullException(nameof(userData));
        }

        public IActionResult OnGet(int id)
        {
            // Consulta SQL para buscar uma obra espec�fica
            var query = "SELECT * FROM Obras WHERE ID_Obra = @IdObra";

            using (var connection = _userData.GetConnection())
            {
                connection.Open();

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@IdObra", id);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Obra = new ObraViewModel
                            {
                                IdObra = reader.GetInt32(reader.GetOrdinal("ID_Obra")),
                                Titulo = reader.GetString(reader.GetOrdinal("Titulo")),
                                Autor = reader.GetString(reader.GetOrdinal("Autor")),
                                Sinopse = reader.IsDBNull(reader.GetOrdinal("Sinopse")) ? null : reader.GetString(reader.GetOrdinal("Sinopse")),
                                CapaBase64 = "/img/default-cover.png"  // Exemplo simples, voc� pode querer tratar as capas aqui.
                            };
                        }
                    }
                }
            }

            if (Obra == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}
