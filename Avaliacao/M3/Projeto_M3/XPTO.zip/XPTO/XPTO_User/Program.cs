using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Authentication.Cookies;
using XPTO_Data;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace XPTO_User
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
            builder.Services.AddSingleton(new UserData(connectionString));  // Registrar UserData como Singleton

            // Configura a autentica��o via cookies
            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.LoginPath = "/login";
                });

            // Adiciona suporte a sess�o
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30); // Tempo de inatividade antes de expirar a sess�o
                options.Cookie.HttpOnly = true;  // Seguran�a: impede acesso do JavaScript
                options.Cookie.IsEssential = true; // Permite sess�o sem consentimento de cookies
            });

            builder.Services.AddRazorPages();

            var app = builder.Build();

            // Configura��o do pipeline de requisi��es
            if (app.Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseSession();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseStaticFiles();

            app.UseRouting();

            app.MapRazorPages();

            app.MapPost("/login", async (HttpContext httpContext) =>
            {
                // L� os dados do formul�rio
                var form = await httpContext.Request.ReadFormAsync();
                var email = form["email"].ToString();
                var password = form["password"].ToString();

                // Verifica se os campos foram preenchidos
                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    httpContext.Response.Redirect("/?loginError=1");
                    return;
                }

                // Recupera a string de conex�o da configura��o
                var config = httpContext.RequestServices.GetRequiredService<IConfiguration>();
                string connectionString = config.GetConnectionString("DefaultConnection");

                // Valida as credenciais usando ADO.NET (UserData)
                var userData = new UserData(connectionString);
                var user = userData.GetUserByEmailAndPassword(email, password);

                if (user == null)
                {
                    // Redireciona de volta para a p�gina inicial com um par�metro de erro
                    httpContext.Response.Redirect("/?loginError=1");
                    return;
                }

                // Cria as claims necess�rias
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.Name),
                    new Claim(ClaimTypes.Email, user.Email)
                    // Adicione outras claims, se necess�rio (ex.: role)
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

                // Realiza o login criando o cookie de autentica��o
                await httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);

                // Redireciona para a p�gina principal ap�s o login
                httpContext.Response.Redirect("/");
            });

            // Endpoint de logout para encerrar a sess�o
            app.MapGet("/logout", async (HttpContext httpContext) =>
            {
                await httpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                httpContext.Response.Redirect("/");
            });

            app.Run();
        }
    }
}