﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MvcAPI.Migrations
{
    /// <inheritdoc />
    public partial class InitialData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Tarefas",
                columns: new[] { "Id", "Concluida", "Descricao", "EndTime", "StartTime" },
                values: new object[,]
                {
                    { 1, false, "Estudar Blazor", new DateTime(2025, 1, 1, 11, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 1, 1, 10, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, false, "Criar um projeto MVC", new DateTime(2025, 1, 2, 16, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 1, 2, 14, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Tarefas",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Tarefas",
                keyColumn: "Id",
                keyValue: 2);
        }
    }
}
