﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MvcAPI.Models
{
    public class Tarefa
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Descricao { get; set; }
        public DateTime StartTime { get; set; } // Task start time
        public DateTime EndTime { get; set; }
        public bool Concluida { get; set; }
    }
}
