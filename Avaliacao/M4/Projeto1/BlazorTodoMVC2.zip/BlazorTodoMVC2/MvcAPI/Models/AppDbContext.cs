﻿using Microsoft.EntityFrameworkCore;

namespace MvcAPI.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        public DbSet<Tarefa> Tarefas => Set<Tarefa>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tarefa>().HasData(
                new Tarefa
                {
                    Id = 1,
                    Descricao = "Estudar Blazor",
                    Concluida = false,
                    StartTime = new DateTime(2025, 1, 1, 10, 0, 0),
                    EndTime = new DateTime(2025, 1, 1, 11, 0, 0)
                },
                new Tarefa
                {
                    Id = 2,
                    Descricao = "Criar um projeto MVC",
                    Concluida = false,
                    StartTime = new DateTime(2025, 1, 2, 14, 0, 0),
                    EndTime = new DateTime(2025, 1, 2, 16, 0, 0)
                }
            );
        }
    }
}
