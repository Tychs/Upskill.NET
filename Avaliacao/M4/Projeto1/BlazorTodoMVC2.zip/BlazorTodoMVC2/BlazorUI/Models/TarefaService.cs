﻿namespace BlazorUI.Models
{
    public class TarefaService
    {
        private readonly HttpClient _http;

        public TarefaService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<Tarefa>> GetTarefasAsync()
        {
            return await _http.GetFromJsonAsync<List<Tarefa>>("api/tarefas");
        }

        public async Task <Tarefa> AdicionarTarefaAsync(Tarefa tarefa)
        {
            var response = await _http.PostAsJsonAsync("api/tarefas", tarefa);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Tarefa>();
        }

        public async Task AtualizarTarefaAsync(Tarefa tarefa)
        {
            var response = await _http.PutAsJsonAsync($"api/tarefas/{tarefa.Id}", tarefa);
            response.EnsureSuccessStatusCode();
        }
        
        public async Task RemoverTarefaAsync(Tarefa tarefa)
        {
            var response = await _http.DeleteAsync($"api/tarefas/{tarefa.Id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
