﻿function mostrarAlerta(mensagem) {
    alert(mensagem);
}
