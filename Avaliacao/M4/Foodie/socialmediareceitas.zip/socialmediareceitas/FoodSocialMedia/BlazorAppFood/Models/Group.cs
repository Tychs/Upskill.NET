﻿namespace BlazorAppFood.Models
{
    public class Group
    {
        public int Id_Group { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
